# Meeting Translator: Claude Opus Local Implementation Pack

Bộ tài liệu này dùng để yêu cầu Claude Opus xây dựng ứng dụng dịch trực tiếp cuộc họp Việt Nam và Nhật Bản hoàn toàn trong thư mục local trên máy tính.

## Mô hình làm việc

- Không sử dụng Git và không yêu cầu commit.
- Source code, tài liệu, log kiểm thử và bản sao lưu đều nằm trong thư mục local.
- Claude được phép tạo và sửa file trên máy phát triển local.
- Claude được phép chạy các kiểm thử local không cần GPU server.
- Claude không được tự đăng nhập, SSH, copy file, cài đặt, khởi động, dừng hoặc thay đổi bất kỳ thứ gì trên GPU server.
- Khi cần thao tác GPU server, Claude phải tạo hướng dẫn từng bước, giải thích kết quả mong đợi, rồi dừng và chờ người dùng phản hồi.
- Claude chỉ được đánh dấu bước GPU hoàn thành sau khi người dùng cung cấp kết quả thực tế.

## Cách bắt đầu

1. Giải nén pack vào một thư mục local, ví dụ:

```text
D:\meeting-translator
```

2. Nên sao lưu thư mục trước từng phase bằng script local do Claude tạo trong Phase 00.
3. Mở thư mục bằng Claude Code hoặc công cụ hỗ trợ Claude Opus.
4. Gửi nội dung `prompts/00_MASTER_PROMPT.md`.
5. Thực hiện lần lượt các prompt trong `prompts/phases/`.
6. Khi Claude đưa ra `MANUAL ACTION REQUIRED`, tự chạy lệnh trên máy hoặc GPU server phù hợp rồi gửi lại nguyên văn output.

## Thứ tự phase

1. Repository foundation local
2. Contracts và protocol
3. Windows audio capture
4. WebSocket streaming
5. VAD và utterance state machine
6. Whisper final
7. Whisper partial và stable prefix
8. Qwen3.6-27B-FP8 với vLLM
9. Completeness và orchestration
10. PySide6 UI
11. Reliability, security và observability
12. End-to-end test và Windows packaging

## File điều phối quan trọng

- `CLAUDE.md`: quy tắc bắt buộc.
- `LOCAL_WORKFLOW.md`: cách làm việc không Git.
- `GPU_MANUAL_WORKFLOW.md`: quy trình thao tác GPU thủ công.
- `IMPLEMENTATION_STATUS.md`: tiến độ và trạng thái xác minh.
- `MANUAL_ACTIONS.md`: Claude ghi các việc người dùng cần thực hiện.
- `USER_RESULTS.md`: nơi lưu kết quả người dùng gửi lại.
- `prompts/00_MASTER_PROMPT.md`: prompt chính.
- `prompts/phases/`: prompt theo từng phase.

## Nguyên tắc phản hồi kết quả thủ công

Khi Claude yêu cầu chạy lệnh, hãy gửi lại:

```text
Action ID: GPU-XXX
Environment: tên máy hoặc mô tả GPU server
Command executed: lệnh đã chạy
Exit status: mã thoát nếu có
Full output: toàn bộ stdout và stderr
Notes: hiện tượng quan sát được
```

Không gửi mật khẩu, private key, access token hoặc nội dung cuộc họp bí mật.
