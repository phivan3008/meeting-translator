# Operator Runbook Seed

Claude must expand this file during implementation.

## Expected deployment

- Application server and Redis run as containers.
- faster-whisper runs on an assigned ASR GPU.
- vLLM runs `Qwen3.6-27B-FP8` on a separate translation GPU.
- A reverse proxy terminates TLS and forwards WebSocket traffic.

## Required runbook sections

- Prerequisites and GPU compatibility.
- Model download and checksum/version recording.
- vLLM launch and health verification.
- Application start and readiness verification.
- Windows client installation.
- Metrics and alert interpretation.
- Queue pressure response.
- Whisper or vLLM OOM response.
- Client reconnect and device-change troubleshooting.
- Safe shutdown.
- Privacy-preserving diagnostics.
- Backup and restore for non-content configuration only.

## vLLM (Qwen3.6-27B-FP8) model download and launch

Written from `docs/ARCHITECTURE.md`'s "Translation server baseline" and
`docs/TRANSLATION.md`. This is documentation only -- these steps are run
manually by the operator on the translation GPU host, per
`GPU_MANUAL_WORKFLOW.md`; Claude never runs them. The application server's
own container (`deployment/Dockerfile`) does not build or run vLLM (GPU
inference stays off that image, per its header comment); vLLM runs as its
own container (or bare process) on the separate translation GPU host.

### Model download and version recording

1. Download `Qwen3.6-27B-FP8` (FP8-quantized weights) to a local path on the
   translation GPU host, e.g. `/models/Qwen3.6-27B-FP8`, using whatever
   internal mirror/registry policy applies -- no download command is
   prescribed here, since that depends on where the weights are hosted for
   this deployment.
2. Record the exact revision/commit hash and total on-disk size of the
   downloaded weights (mirrors how `GPU-ASR-004`/`USER_RESULTS.md` recorded
   the faster-whisper `large-v3` revision and size for the ASR model). Keep
   this alongside deployment records, not in source control.
3. Confirm available disk and VRAM are sufficient for an FP8 27B model
   (tens of GB on disk; see `docs/ARCHITECTURE.md`'s GPU allocation
   guidance -- do not assume it safely coexists with Whisper `large-v3` on
   one 48 GB GPU under production load).

### vLLM launch (Docker)

Official vLLM OpenAI-compatible server image, run on the translation GPU
host (adjust the image tag/model path/GPU device to the actual
deployment):

```bash
docker run --rm -d \
  --name vllm-translate \
  --gpus '"device=0"' \
  -v /models/Qwen3.6-27B-FP8:/models/Qwen3.6-27B-FP8:ro \
  -p 8000:8000 \
  vllm/vllm-openai:latest \
  --model /models/Qwen3.6-27B-FP8 \
  --served-model-name qwen3.6-27b-translate \
  --host 0.0.0.0 \
  --port 8000 \
  --language-model-only \
  --max-model-len 4096 \
  --max-num-seqs 32 \
  --max-num-batched-tokens 4096 \
  --gpu-memory-utilization 0.88 \
  --enable-prefix-caching \
  --trust-remote-code \
  --default-chat-template-kwargs '{"enable_thinking": false}'
```

Equivalent bare-process launch (no Docker) is the `vllm serve ...` command
already documented in `docs/ARCHITECTURE.md`'s "Translation server
baseline" -- both forms serve the same OpenAI-compatible API that
`server/translation/client.py` (`VllmTranslationClient`) talks to.

MTP speculative decoding is an optional benchmark feature, not a mandatory
default (`docs/ARCHITECTURE.md`).

### Health verification

```bash
curl -s http://<translation-gpu-host>:8000/v1/models
```

Expected: a JSON body listing `qwen3.6-27b-translate` as an available
model, with no error. A minimal two-direction translation smoke test (one
Japanese-to-Vietnamese request, one Vietnamese-to-Japanese request) against
`/v1/chat/completions` is the next staged manual action after this health
check passes -- see `MANUAL_ACTIONS.md` for the exact, currently-pending
action.

### Application-side configuration

The application server reaches vLLM via `VLLM_BASE_URL` (`.env.example`,
default `http://localhost:8000/v1`) and `VLLM_MODEL`
(`qwen3.6-27b-translate`) -- point `VLLM_BASE_URL` at the translation GPU
host's address once vLLM is confirmed healthy.
