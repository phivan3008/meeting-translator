"""Tests for the FastAPI liveness and readiness endpoints."""

from __future__ import annotations

from fastapi.testclient import TestClient

from server.app import create_app
from shared.settings import Settings


def _client() -> TestClient:
    settings = Settings(_env_file=None)  # type: ignore[call-arg]
    return TestClient(create_app(settings))


def test_liveness_ok() -> None:
    client = _client()
    response = client.get("/health/live")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "alive"
    assert body["app_env"] == "development"


def test_readiness_ok() -> None:
    client = _client()
    response = client.get("/health/ready")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ready"
    assert body["checks"]["settings"] is True
