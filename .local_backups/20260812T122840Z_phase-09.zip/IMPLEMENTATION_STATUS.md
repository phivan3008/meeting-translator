# Implementation Status

## Current phase

Phase 08: Completeness and finalization orchestration.

## Verification state

- Local verification: LOCAL_VERIFIED (Phase 00, Phase 01, Phase 02, Phase 03, Phase 04, Phase 05,
  Phase 06, Phase 07, Phase 08). A pre-existing, Phase-06-unrelated failure in
  `test_transport_sender.py` found while running Phase 06's checks was
  investigated and fixed (see "Bug fix: sender reconnect cancellation race"
  under "Known limitations"); the full suite is clean.
- Windows audio verification: HARDWARE_VERIFIED (WINDOWS-AUDIO-001 PASSED 2026-08-10)
- GPU ASR verification: HARDWARE_VERIFIED for the `WhisperAsrModel` adapter
  itself (GPU-ASR-001 environment inspection PASSED 2026-08-10; GPU-ASR-002
  faster-whisper install INCONCLUSIVE 2026-08-11, superseded; GPU-ASR-003
  ctranslate2/CUDA visibility PASSED 2026-08-11; GPU-ASR-004 real model
  load/decode smoke test PASSED 2026-08-11; GPU-ASR-005 real-speech adapter
  test PASSED 2026-08-12, user confirmed both vi/ja transcripts roughly
  accurate). Still HARDWARE_PENDING for gateway/VAD-integrated end-to-end use
  and for scored accuracy/latency benchmarking — neither has been attempted.
- GPU translation verification: HARDWARE_VERIFIED for the
  `VllmTranslationClient`/prompt-building code path itself.
  `GPU-TRANSLATE-001` (environment inspection), `GPU-TRANSLATE-002` (model
  download), `GPU-TRANSLATE-005` (vLLM launch, after patching a
  third-party `flashinfer` bug that failed
  `GPU-TRANSLATE-003`/`GPU-TRANSLATE-004`), `GPU-TRANSLATE-006` (HTTP
  health check) and `GPU-TRANSLATE-007` (real two-direction translation
  request through the project's own prompt-building code) all PASSED
  2026-08-12: the server is up, answers `/health` (200) and `/v1/models`
  correctly (served id `qwen3.6-27b-translate`, `max_model_len=4096`
  matching the launch config), and produced plausible, correctly-scripted
  translations in both directions (JA->VI and VI->JA) with no
  exception/traceback and confirmed real generation in the engine log. See
  "Known limitations" for a caveat on how the JA/VI plausibility judgment
  was made. This was the last of Phase 07's staged GPU checkpoints; still
  HARDWARE_PENDING for wiring into the live gateway/VAD/ASR pipeline and
  for scored accuracy/latency benchmarking (both explicitly out of this
  phase's scope).
- Completeness/orchestration verification (Phase 08): LOCAL_VERIFIED only.
  The full pipeline (`UtteranceOrchestrator`) and the completeness
  heuristic are pure/composed logic exercised entirely with scripted ASR
  and translation fakes -- no GPU work is required to implement or test
  this phase's own scope. However, the completeness-check prompt/JSON
  schema (`CompletenessClassifier`) has never been sent to the real,
  already-running vLLM server -- only `TranslationClient.complete_chat`'s
  existing translation-prompt path was hardware-verified in Phase 07
  (`GPU-TRANSLATE-007`). Whether Qwen3.6-27B-FP8 reliably returns valid
  `{"complete": bool, "confidence": float}` JSON for this new prompt is
  therefore HARDWARE_PENDING; see "Known limitations". Not staged as a
  `MANUAL_ACTIONS.md` entry yet since it was not required to complete this
  phase's own local scope -- available on request.
- Hardware end-to-end verification: NOT_STARTED

## Completed

- [x] Phase 00: Local project foundation and backup workflow
- [x] Phase 01: Contracts and protocol
- [x] Phase 02: Windows audio capture
- [x] Phase 03: WebSocket streaming
- [x] Phase 04: VAD and utterance state machine
- [x] Phase 05: Final Whisper ASR
- [x] Phase 06: Partial Whisper ASR and stable prefix
- [x] Phase 07: Qwen translation with vLLM
- [x] Phase 08: Completeness and finalization orchestration
- [ ] Phase 09: PySide6 client UI
- [ ] Phase 10: Reliability, security and observability
- [ ] Phase 11: End-to-end tests and Windows packaging

## Latest local snapshot

`.local_backups/20260812T104740Z_phase-08.zip`. Process note: per
`LOCAL_WORKFLOW.md` this snapshot should have been taken *before* editing;
it was instead taken after Phase 08's implementation was already complete
(an oversight during this session) rather than before starting, so it is
not a clean pre-Phase-08 rollback point. `.local_backups/20260811T184112Z_phase-07.zip`
(the pre-Phase-07/end-of-Phase-07 snapshot) remains the most recent
snapshot that predates any Phase 08 change and is the correct target if a
rollback to before this phase is needed. Excludes `.venv`, `.local_backups`,
models, caches, logs, recordings and secrets; `.env.example` retained.
Manifest with per-file SHA-256 alongside each zip.
`.local_backups/20260811T182415Z_sender-cancel-race-fix.zip`,
`.local_backups/20260811T173029Z_phase-06.zip` and prior
Phase 00/01/02/03/04/05 snapshots are retained.

## Commands last run locally

```
python scripts/local_backup.py --label phase-08
ruff format .
ruff check .
mypy client server shared
pytest -m "not gpu and not windows_audio"
```

Note: this environment's `.venv` had only the base package installed (no
`dev` extra) at the start of Phase 06; `pip install -e ".[dev]"` was already
run then and remains sufficient for Phase 08 (no new dependency was added).

## Local test results

- ruff format: PASS (3 files reformatted, 142 unchanged)
- ruff check: PASS (all checks passed)
- mypy client server shared: PASS (no issues in 67 source files)
- pytest (CPU, not gpu/not windows_audio): 291 passed, 0 failed, 2 deselected
  (293 collected)
  - Phase 08 orchestration/completeness suites (33 new):
    - test_orchestration_heuristics.py: 12 passed (Vietnamese/Japanese
      sentence-ending punctuation is definite-complete, language-specific
      ending signals without punctuation are definite-complete, a long
      unstable tail is definite-incomplete (not ambiguous), empty stable
      text is definite-incomplete, too-short confirmed speech duration
      makes an otherwise-matching punctuation signal ambiguous instead of
      definite, no-signal text is ambiguous with a deterministic
      (incomplete) fallback, a short unstable tail within the configured
      threshold does not block completion, invalid config rejected,
      `from_settings` reads the `completeness_heuristic_*` fields)
    - test_translation_completeness.py: 11 passed (valid complete/incomplete
      JSON parsed, JSON wrapped in extra text/markdown fences is still
      extracted, missing keys/wrong types/bool-as-confidence are all
      treated as invalid (unknown), a scripted backend
      timeout/overloaded error is unknown, the classifier's own
      `wait_for` timeout is enforced independent of the backend, invalid
      config rejected)
    - test_orchestration_pipeline.py: 8 passed, exercising the full
      `UtteranceOrchestrator` (VAD -> partial ASR -> final ASR ->
      translation -> final event) against `ScriptedAsrModel`/
      `ScriptedTranslationClient` fakes -- no GPU/model weights: hard
      silence finalizes without a completeness check when no
      punctuation/ending-signal is present; a definite-complete heuristic
      verdict at soft silence finalizes early as `semantic_complete`
      (before hard silence); a stale soft-silence decision is discarded
      (no early finalize) when speech resumes before the decision
      resolves (uses a real, artificially-delayed completeness call to
      create a genuine race window); hard silence firing synchronously
      before a still-pending soft-silence decision gets a chance to run
      results in *exactly one* `utterance.final` (race-safe, no double
      finalize); a completeness-check timeout falls back to the
      deterministic (incomplete) verdict rather than wrongly finalizing;
      two streams with independently-open utterances finalize
      independently with distinct utterance ids and correct stream
      attribution; `flush_stream` forces finalization while still
      actively speaking (`client_flush`); a failed initial translation
      publishes `utterance.final` with `translation_status=failed`
      immediately and a later successful retry publishes a separate
      `translation.updated` event.
    - `server/vad/state_machine.py` gained a read-only `speech_ms`
      property (exposes the state machine's existing internal counter for
      the heuristic's "stable duration" signal); 1 new test in
      `test_vad_state_machine.py`.
    - `server/asr/partial.py` gained `PartialTranscriber.current_text()`
      (exposes the last-published stable/unstable text without forcing a
      new decode, for the completeness decision to read); 1 new test in
      `test_asr_partial.py`.
  - All Phase 08 tests are pure, use `ScriptedAsrModel`/
    `ScriptedTranslationClient`, or use small local fakes with an
    artificial `asyncio.sleep` -- no real Whisper/vLLM/CUDA, no network
    access, and no model weights are downloaded.
  - Phase 07 translation suites (72):
    - test_translation_types.py: 8 passed (config defaults/from_settings
      mapping/validation, glossary entry validation, request validation
      (empty text, same source/target language), outcome validation
      (COMPLETED requires text, FAILED forbids text))
    - test_translation_errors.py: 5 passed (error kinds/retryable flags,
      error-code mapping, backend-exception classification for
      timeout/connection/default-to-failed)
    - test_translation_fake.py: 4 passed (scripted ordering/clamp, call
      recording, scripted error, empty-outcomes guard)
    - test_translation_prompts.py: 11 passed (JA->VI and VI->JA system
      prompts match docs/TRANSLATION.md's requirements text, unsupported
      direction rejected, glossary block rendering and relevance filtering
      (case-insensitive), corrective-prompt suffix appended for retries,
      user content with/without context trimmed to at most 2 prior
      sentences, completeness-check prompt matches the documented schema)
    - test_translation_validator.py: 15 passed (valid vi/ja outputs pass;
      empty output, forbidden prefix (English and Vietnamese labels),
      pathological repetition for Vietnamese (space-delimited) and Japanese
      (no spaces), wrong-language detection both directions, missing
      version/URL preservation rejected, preserved version+date passes,
      length ratio too short and too long rejected)
    - test_translation_client.py: 9 passed against `httpx.MockTransport`
      (no real vLLM server): correct request payload (model, temperature 0,
      top_p 1, stream false, non-thinking `chat_template_kwargs`), auth
      header sent, HTTP 429/503 -> overloaded, HTTP 500 -> failed, timeout ->
      timeout error, malformed/missing-choices JSON -> failed, an injected
      `httpx.AsyncClient` is not closed by `aclose()`
    - test_translation_queue.py: 9 passed (final drains before retry before
      completeness, FIFO within a priority, a newer final item still drains
      before an older retry, bounded per-priority lane rejected explicitly
      on overflow without affecting other lanes, qsize totals,
      `should_skip_completeness` threshold behavior)
    - test_translation_worker.py: 11 passed (`translate_once` success and
      validation-failure paths (no auto-retry), backend-error mapping,
      `wait_for` timeout enforcement, `retry()` uses a corrective prompt
      after a validation failure vs. the original prompt after a timeout,
      bounded concurrency actually caps concurrent in-flight calls,
      glossary/context reach the client, `apply_translation` returns a new
      event without mutating the original, `build_translation_updated`
      requires a COMPLETED outcome)
  - All translation tests are either pure (types/errors/fake/prompts/
    validator/queue), use `ScriptedTranslationClient`, or use
    `httpx.MockTransport` -- no real vLLM server or network access, and no
    model weights are downloaded.
  - Phase 06 partial-ASR suites (36):
    - test_asr_stable_prefix.py: 10 passed (first-hypothesis no-commit,
      two-hypothesis agreement for Vietnamese and Japanese (no spaces),
      punctuation-variation does not prematurely commit, a later contradicting
      hypothesis does not rewrite committed text, committed text never
      shrinks across a sequence, stable-boundary-ms segment mapping, window
      reset keeps committed text but restarts agreement, finalize)
    - test_asr_sliding_window.py: 9 passed (append/accumulate, advance
      no-ops on a non-positive boundary, advance keeps the overlap margin,
      advance clamps at zero when overlap exceeds the boundary, advance
      clamps to the actually-buffered length so it can never over-trim,
      advance is relative to the current window across repeated trims)
    - test_asr_partial_scheduler.py: 9 passed (interval validation, not due
      before the interval, due-and-reschedule, stop removes an utterance,
      independent streams scheduled by their own start time, simultaneous
      due utterances all returned so none is starved, a missed/late tick
      reschedules from "now" rather than the missed due time so it cannot
      burst catch-up decodes)
    - test_asr_partial.py: 10 passed (unknown/no-audio utterances return no
      event, first partial event published with correct revision/text/
      timing, duplicate stable+unstable text is suppressed, revision only
      increases on a real content change, `previous_text` conditioning uses
      the committed text, a decode superseded by a newer one or by the
      utterance being stopped mid-flight is discarded rather than applied)
  - `AsrConfig` gained `partial_beam_size` (mirrors `whisper_partial_beam_size`);
    test_asr_config.py extended with 1 new test (2 new assertions total).
  - All partial-ASR tests use `ScriptedAsrModel`; no weights are downloaded,
    no real Whisper/CUDA/asyncio-timer dependency.
  - A pre-existing failure unrelated to Phase 06,
    `tests/test_transport_sender.py::test_run_reconnects_and_resends_pending`
    (Phase 03 client reconnect test, deterministic 2s timeout in this
    environment), was investigated at the user's request and fixed; see
    "Bug fix: client reconnect cancellation race" below. It now passes
    (0.117s) and the suite has 0 failures.
  - (Prior 129 VAD/transport/protocol/audio tests otherwise unchanged.)
- windows_audio-marked tests remain deselected on this environment.
- One non-blocking warning: Starlette TestClient httpx deprecation notice
  (from FastAPI test client, not project code).

## Phase 03 deliverables

Server transport (`server/transport/`):
- `auth.py`: `Authenticator` interface, `AuthContext`, `AuthError`, and the
  functional dev `StaticTokenAuthenticator` (anonymous in non-production or a
  constant-time shared-token check). Production JWT validation slots in behind
  the same interface; no placeholder crypto shipped.
- `limits.py`: monotonic-time `TokenBucket` packet rate limiter.
- `jitter_buffer.py`: per-stream reorder buffer; holds out-of-order packets,
  releases contiguously, deduplicates, rejects stale packets, and force-advances
  past oversized gaps (bounded capacity, reported loss).
- `acks.py`: `AckBatcher` emitting one `audio.ack` per N packets or T ms.
- `session.py`: `StreamContext`, `Session`, `SessionManager` built from a
  validated `session.start` (unique ids, per-stream contexts, stream cap).
- `gateway.py`: FastAPI `/ws/stream` endpoint — handshake + validation, auth,
  independent binary ingest per stream, batched acks, payload/rate limits,
  keepalive/idle handling and typed `error` events. Never logs payloads/text.

Client transport (`client/transport/`):
- `backoff.py`: deterministic exponential `ReconnectBackoff` with optional
  injectable jitter.
- `outbound.py`: bounded `OutboundBuffer` (drop-oldest) of unacked frames for
  idempotent resend.
- `sender.py`: `AudioSender` with a `Transport` protocol (injectable),
  session handshake, per-stream sequence assignment, ack-driven buffer
  release, and a reconnect loop that resends unacked frames on each connect.
  `WebSocketClientTransport` (lazy `websockets`) provides the real socket.
  `_serve()` shuts down its pump tasks via a `_cancel_and_wait` helper that
  retries cancellation until both tasks actually finish, rather than a
  single `cancel()` call (see "Bug fix: client reconnect cancellation race"
  under "Known limitations").

Wiring/tooling:
- `server/app.py` now mounts the gateway with a dev authenticator and session
  manager.
- `shared/settings.py` + `.env.example`: transport, ack-batching, jitter,
  idle/heartbeat, rate-limit, auth-token and reconnect settings.
- mypy override treats `websockets` as an external untyped import.

## Phase 04 deliverables

VAD segmentation (`server/vad/`), pure synchronous CPU logic with no I/O,
FastAPI, Qt or CUDA coupling:
- `types.py`: audio constants (16 kHz S16LE, `BYTES_PER_MS`), the `VadState`
  enum (IDLE, SPEECH_STARTING, SPEAKING, POSSIBLE_END, FINALIZING), the frozen
  `VadConfig` (thresholds/durations/padding with validation and a
  `from_settings` mapping) and the frozen `Utterance` value object (id, source,
  timestamps, speech duration, final reason, audio buffer).
- `events.py`: `VadEventType` and frozen event records `SpeechStarted`,
  `SoftSilence`, `ResumedSpeech`, `UtteranceFinalized`, plus the `VadEvent`
  union.
- `interface.py`: `VadModel` runtime-checkable protocol (`probability`,
  `reset`) documented to run off the event loop.
- `fake.py`: deterministic `ScriptedVadModel` for tests (per-call probabilities,
  clamps to the last value when exhausted, `reset` rewinds).
- `silero.py`: `SileroVadModel` adapter with lazy `torch`/`silero_vad`
  initialization, 512-sample windowing and int16→float32 conversion; kept out
  of the CPU suite.
- `ring_buffer.py`: bounded `PreRollBuffer` (deque of recent frames) supporting
  pre-roll snapshots; disabled cleanly when capacity is below one frame.
- `state_machine.py`: `UtteranceSegmenter` — the per-stream IDLE/
  SPEECH_STARTING/SPEAKING/POSSIBLE_END machine. Confirms speech after
  `speech_start_ms`, prepends pre-roll audio, emits speech-start, soft-silence
  (once) and resumed-speech events, finalizes on hard silence or max utterance,
  trims trailing silence to `speech_pad_after_ms`, discards sub-`min_speech_ms`
  utterances (unless force-flushed), assigns incrementing utterance ids, and
  supports forced finalization via `flush(reason)`.

Tooling:
- mypy override extended to treat `silero_vad` and `torch` as external untyped
  imports.

## Manual actions waiting for user

### GPU-ASR-001 (PASSED 2026-08-10)

Read-only inspection of the ASR GPU host: NVIDIA H100 80GB HBM3 (0 MiB used),
driver 580.82.07, CUDA (driver) 13.0, nvcc 12.8, 128 CPUs, 1.5 TiB RAM (696 GiB
free), ample disk on both the container overlay and the persistent `/workspace`
PVC, Python 3.11.13. Host is a containerized/Kubernetes pod, not bare metal. No
errors observed. Full output is recorded in `USER_RESULTS.md`; the action entry
is now under "Completed actions" in `MANUAL_ACTIONS.md`.

### GPU-ASR-002 (INCONCLUSIVE 2026-08-11, superseded)

Installed `faster-whisper` 1.2.1 into a venv on the GPU host successfully
(real path confirmed by GPU-ASR-003 as
`/workspace/meetting-translator/.venv-asr`, not `/workspace/.venv-asr` as
first assumed). The action also asked for `import torch`, which failed with
`ModuleNotFoundError`. That check was a mistake in the action, not a real
signal: `faster-whisper` runs inference through CTranslate2, and the
project's `pyproject.toml` `gpu` extra pins only `faster-whisper>=1.0,<2`
with no PyTorch dependency, so a missing `torch` module proves nothing about
GPU readiness. Full result recorded in `USER_RESULTS.md`; action entry moved
to "Completed actions" (INCONCLUSIVE) in `MANUAL_ACTIONS.md`.

### GPU-ASR-003 (PASSED 2026-08-11)

Corrected diagnostic: `ctranslate2` 4.8.1 installed, `cuda_device_count()`
returned 1 (CTranslate2 sees the H100). Active interpreter and installed
packages confirmed inside the venv; `nvidia-smi` matched GPU-ASR-001.
`libcudart`/`libcublas`/`libcublasLt` resolved via `ldconfig`; `libcudnn`
did not appear in that listing. Per this action's own stated success
criteria (a missing `ldconfig` match only disqualifies if
`cuda_device_count` is 0), this is not treated as a failure, but it is an
open question carried into GPU-ASR-004: a real model load/decode is the
only way to confirm cuDNN (if needed by CTranslate2's ops) is actually
resolvable, since enumerating a CUDA device does not require loading a
model. Full result recorded in `USER_RESULTS.md`; action entry moved to
"Completed actions" in `MANUAL_ACTIONS.md`.

### GPU-ASR-004 (PASSED 2026-08-11)

First real GPU decode: downloaded `large-v3` weights (revision
`edaa852ec7e145841d8ffdb056a99866b5f0a478`, ~2.88 GiB) and ran one
`model.transcribe()` call against a locally-synthesized sine tone. Model
load (3.66s) and decode (0.29s) both completed with no CUDA/cuDNN/cuBLAS
error — resolving the open question from GPU-ASR-003 about `libcudnn` not
appearing in `ldconfig`. Still not an accuracy test (synthetic tone, no real
speech). Full result recorded in `USER_RESULTS.md`; action entry moved to
"Completed actions" in `MANUAL_ACTIONS.md`.

### GPU-ASR-005 (PASSED 2026-08-12)

First real-speech, real-code-path check: ran the project's own
`WhisperAsrModel` adapter (`server/asr/whisper.py`), built with the
project's documented `AsrConfig` defaults, against two real-speech WAV
samples (`vi_sample.wav`, 28s; `ja_sample.wav`, 20s). No exception for
either language; `segments > 0` for both (7 and 8); both outputs are
fluent, coherent, well-formed text in their respective language (Vietnamese
company-profile passage; Japanese textbook sentence-pattern examples) — see
`USER_RESULTS.md` for full text. User confirmed the ground-truth criterion:
"yes, the printed text is a roughly accurate rendering of what i said," for
both clips. This is the first hardware confirmation that the project's own
ASR adapter code (not just bare faster-whisper/ctranslate2) produces
plausible real transcripts in both target languages. Broader scored
accuracy/latency benchmarking and wiring `FinalTranscriber` into the live
gateway/VAD path remain separate, not-yet-started work.

No ASR manual action is currently pending.

### GPU-TRANSLATE-001 (PASSED 2026-08-12)

Read-only inspection: 1x NVIDIA H100 80GB HBM3 (0 MiB used), driver
580.82.07, CUDA (driver) 13.0, nvcc 12.8, 128 CPUs, 1.5 TiB RAM (596 GiB
free), `/workspace` PVC 300G (155G avail). Docker check intentionally
skipped -- user intends the bare-process `vllm serve` launch path. No
errors observed. Confirmed: this is the *same physical host and the same
single GPU* already used for ASR (`GPU-ASR-001`-`GPU-ASR-005`), not a
separate GPU as `docs/ARCHITECTURE.md` recommends. Flagged explicitly (see
"Known limitations") rather than silently accepted -- 80 GB of VRAM gives
meaningful headroom for both models' likely combined footprint, but final
co-location suitability under real concurrent production load is a
capacity-planning judgment call, not verified here. Full output recorded in
`USER_RESULTS.md`; action entry moved to "Completed actions" in
`MANUAL_ACTIONS.md`.

### GPU-TRANSLATE-002 (PASSED 2026-08-12)

Downloaded the official `Qwen/Qwen3.6-27B-FP8` weights (confirmed real via
web search, ~30.9 GB) into
`/workspace/meetting-translator/models/Qwen3.6-27B-FP8`, in a new
`.venv-translate` kept separate from `.venv-asr`. Resolved revision
`e89b16ebf1988b3d6befa7de50abc2d76f26eb09`; 80 files, 8m11s; `du -sh`
reports 29G, consistent with the download tool's own "30.9GB / 30.9GB
complete" report. No exception. Full output recorded in `USER_RESULTS.md`;
action entry moved to "Completed actions" in `MANUAL_ACTIONS.md`.

### GPU-TRANSLATE-003 (FAILED 2026-08-12)

`pip install vllm` succeeded, but launching (`vllm serve ...`) crashed
during model construction: `TypeError: type 'array.array' is not
subscriptable` inside `flashinfer/comm/fd_exchange.py`, imported as part
of vLLM's `torch.compile` backend setup (`AllReduceFusionPass`). Root
-caused via the traceback plus reading vLLM's own source on GitHub: this
is a genuine bug in the installed `flashinfer` package (`array.array`
does not support subscripting, so `array.array[int]` as a type annotation
always fails at import time) -- not caused by this project, the download,
or the host environment. Full analysis in `USER_RESULTS.md`; action entry
moved to "Completed actions" in `MANUAL_ACTIONS.md`.

### GPU-TRANSLATE-004 (FAILED 2026-08-12)

Retried the vLLM launch with `--enforce-eager` added. This correctly fixed
the targeted crash: model construction succeeded (weights loaded in 23.7s,
27.67 GiB; KV cache computed: 41.03 GiB available, 292,522 tokens). But
`EngineCore` then crashed on the *same* `flashinfer` `array.array[int]`
bug via a *different* import chain: `kernel_warmup()` unconditionally
imports MiniMax-M3-specific warmup code (unrelated to the Qwen3.5 model
being served), which transitively imports the same broken
`flashinfer.comm`. Full analysis in `USER_RESULTS.md`; action entry moved
to "Completed actions" in `MANUAL_ACTIONS.md`.

### GPU-TRANSLATE-005 (PASSED 2026-08-12)

Patched the one broken line in the installed `flashinfer` package
(`.venv-translate/.../flashinfer/comm/fd_exchange.py`) by quoting the
invalid `array.array[int]` return-type annotation as a string, then
relaunched (`--enforce-eager` kept). Server reached full startup this
time: "Started server process", "Application startup complete.", "API
server: HTTP server started" -- no traceback. `nvidia-smi`:
`72237/81559 MiB` used, consistent with weights (~27.67 GiB) + KV cache
(~41.03 GiB) both resident, no OOM. This is the first successful vLLM
server start across five launch-related actions. Explicitly a local,
venv-scoped workaround, not a permanent fix (reinstalling/upgrading
`flashinfer`/`vllm` in this venv would overwrite it). Full output recorded
in `USER_RESULTS.md`; action entry moved to "Completed actions" in
`MANUAL_ACTIONS.md`.

### GPU-TRANSLATE-006 (PASSED 2026-08-12)

First HTTP-level confirmation that the running server actually answers
OpenAI-compatible requests and serves the expected model name: `/health`
returned `http_status=200`; `/v1/models` returned a well-formed
OpenAI-compatible listing (`id=qwen3.6-27b-translate`,
`root=/workspace/meetting-translator/models/Qwen3.6-27B-FP8`,
`max_model_len=4096`, matching the launch config exactly and matching
`VLLM_MODEL` in `.env.example`). No error, timeout or unexpected status.
Full output recorded in `USER_RESULTS.md`; action entry moved to
"Completed actions" in `MANUAL_ACTIONS.md`.

### GPU-TRANSLATE-007 (PASSED 2026-08-12)

The last of this phase's staged GPU checkpoints: a real two-direction
translation request (Japanese->Vietnamese, Vietnamese->Japanese) through
the project's own prompt-building code (`server/translation/prompts.py`'s
`build_system_prompt`/`build_user_content`) against the running vLLM
server. Both requests returned `200 OK` with no exception/traceback:
JA->VI "来週のリリースについて確認したいです。" -> "Tôi muốn xác nhận về
bản phát hành vào tuần tới."; VI->JA "Tôi muốn xác nhận về đợt phát hành
vào tuần tới." -> "来週のリリースについて確認したいのですが。" Both
correctly scripted, no forbidden prefix, no repetition; the vLLM engine
log confirms real generation (non-zero throughput, non-zero KV cache
usage). See "Known limitations" for a note on how the plausibility
judgment was made. No further translation-specific manual action is
currently pending.

No translation manual action is currently pending.

## Phase 05 deliverables

Final ASR (`server/asr/`), framework-independent domain logic plus a lazy GPU
adapter:
- `types.py`: audio constants, the frozen `AsrConfig` (model/device/
  compute_type/final_beam_size/temperature/condition_on_previous_text with
  validation and a `from_settings` mapping to the `whisper_*` baseline),
  `AsrRequest` (audio + decode options + optional conditioning prompt, with a
  `duration_ms` helper) and the frozen result models `TranscriptionSegment` /
  `TranscriptionResult`.
- `errors.py`: `AsrErrorKind` and the typed `AsrError` hierarchy
  (`ModelUnavailableError`, `AsrTimeoutError`, `AsrOutOfMemoryError`,
  `AsrDecodeError`) with `retryable` flags, an `error_code` mapping to
  `ErrorCode.ASR_FAILED`, and `classify_backend_error` to normalize backend
  exceptions (OOM / model-missing / decode) without importing GPU libraries.
- `interface.py`: `AsrModel` runtime-checkable protocol documented to run off
  the event loop.
- `fake.py`: deterministic `ScriptedAsrModel` (scripted results/errors, request
  recording) for CPU tests.
- `whisper.py`: `WhisperAsrModel` faster-whisper adapter with lazy `WhisperModel`
  load, int16->float32 conversion, per-language decode with beam/temperature/
  conditioning, and backend-error mapping. Excluded from the CPU suite.
- `worker.py`: `FinalTranscriber` runs decoding in a dedicated single-worker
  executor (never blocks the event loop; final ASR prioritized/serialized),
  enforces `asr_final_timeout_ms` via `wait_for` (timeout -> `AsrTimeoutError`),
  performs final reconciliation over completed utterance audio, and `finalize()`
  builds the `utterance.final` event with the transcription and
  `translation=None` / `translation_status=pending`. `build_asr_error_event`
  maps a typed error to a protocol `error` event.

Configuration/tooling:
- `shared/settings.py` + `.env.example`: added `whisper_final_beam_size`,
  `whisper_partial_beam_size`, `whisper_temperature`,
  `whisper_condition_on_previous_text` and `asr_final_timeout_ms`.
- mypy override extended to treat `faster_whisper` as an external untyped import.

## Phase 06 deliverables

Streaming partial ASR (`server/asr/`), pure/testable domain logic plus a thin
async orchestrator, mirroring the layering already used for transport
(`AckBatcher`) and final ASR (`FinalTranscriber`) — no gateway/VAD wiring yet
(consistent with Phase 05's `FinalTranscriber`, which is also not yet wired
into the live ingest path):
- `stable_prefix.py`: `StablePrefixTracker`/`StablePrefixResult` — pure,
  Whisper-independent local-agreement text merging. Commits text only once it
  agrees, segment-for-segment, across two consecutive decodes of the same
  audio window (comparing whole Whisper segments, not characters or
  whitespace-split words, so it works uniformly for Japanese and Vietnamese
  and never truncates mid-token). Committed text is monotonic — a later
  contradicting hypothesis cannot rewrite it. `stable_boundary_ms` maps the
  committed prefix back to a window-relative audio timestamp for windowing;
  `reset_window` restarts the agreement baseline (without discarding
  committed text) after the audio window shifts; `finalize` commits full text.
- `sliding_window.py`: `SlidingAudioWindow` — pure, growing PCM buffer for one
  in-progress utterance. `advance` drops audio already confirmed stable,
  keeping a configurable `overlap_ms` safety margin before the boundary (so a
  word spanning the trim point is not cut acoustically) and clamps to what is
  actually buffered so a boundary from an inconsistent backend can never
  over-trim. Continuity for dropped audio comes from feeding committed text
  back as `AsrRequest.previous_text`, not from re-decoding it.
- `partial_scheduler.py`: `PartialDecodeScheduler` — pure, time-injected
  (matches `AckBatcher`'s style) per-utterance due-time tracking at a
  configurable interval (`whisper_partial_interval_ms`, default 500ms).
  Independent per-stream due times, all simultaneously-due utterances
  returned (no stream starved), and a missed/slow tick reschedules from "now"
  rather than the missed due time so a gap cannot cause a catch-up burst.
- `partial.py`: `PartialTranscriber` — composes the above with an `AsrModel`
  to produce `transcription.partial` events. Runs decoding off the event loop
  in a dedicated executor (like `FinalTranscriber`); per-utterance state
  (window, tracker, revision, last-published text, a decode "generation"
  counter). Protections: duplicate stable/unstable text is not republished;
  revision only increases and only on a real change; a decode result that
  completes after the utterance was stopped or after a newer decode
  superseded it is discarded rather than applied (checked via the generation
  counter and utterance presence, both re-checked after the `await`).
  `current_revision` is exposed for a future final-reconciliation caller to
  assign the final event a strictly higher revision than the last partial
  (not wired up in this phase — final ASR's own revision handling is
  untouched, per "final reconciliation remains authoritative").

Configuration:
- `types.py`: `AsrConfig` gained `partial_beam_size: int = 1` (validated >= 1)
  and `from_settings` now maps `whisper_partial_beam_size`. `final_beam_size`
  and `FinalTranscriber` are unchanged.

Not in this phase's scope (consistent with Phase 05 precedent and the phase
prompt's own scope): a live asyncio loop driving `PartialDecodeScheduler` on
a wall clock, and wiring `PartialTranscriber`/`FinalTranscriber` into the
gateway/VAD ingest path. See "Known limitations".

## Phase 07 deliverables

Qwen3.6-27B-FP8 translation via vLLM (`server/translation/`), framework
-independent domain logic plus a plain async HTTP adapter (unlike the ASR/
VAD GPU adapters, `httpx` is CPU-only and already in the `dev`/`server`
extras, so the client is imported directly and fully unit-tested against a
local mock transport, not excluded from the CPU suite):
- `types.py`: `TranslationConfig` (base_url/api_key/model/token limits/
  timeout/concurrency from `vllm_*`/`translation_*` settings via
  `from_settings`; temperature 0 and top-p 1 are fixed constants, not
  settings-driven, per the documented baseline), `GlossaryEntry`,
  `TranslationRequest` (finalized text + source/target language + glossary +
  at most `MAX_CONTEXT_SENTENCES`=2 prior sentences, with validation), and
  `TranslationOutcome` (text/status/issue, with validation that a COMPLETED
  outcome carries text and a FAILED one does not).
- `errors.py`: `TranslationErrorKind` and the typed `TranslationError`
  hierarchy (`TranslationTimeoutError`, `TranslationOverloadedError`,
  `TranslationFailedError`) with `retryable` flags, an `error_code` mapping
  to `TRANSLATION_TIMEOUT`/`OVERLOADED`/`TRANSLATION_FAILED`, and
  `classify_backend_error` to normalize backend exceptions without
  requiring callers to import `httpx` exception types.
- `interface.py`: `TranslationClient` runtime-checkable protocol (plain
  async, no executor needed, unlike the ASR/VAD model protocols).
- `fake.py`: deterministic `ScriptedTranslationClient` (scripted
  results/errors, call recording) for CPU tests.
- `prompts.py`: `build_system_prompt` (JA->VI and VI->JA templates matching
  docs/TRANSLATION.md verbatim, glossary substitution, a corrective-prompt
  suffix for the retry path), `build_user_content` (current text plus at
  most 2 trailing prior sentences as explicitly non-translatable context),
  `select_relevant_glossary` (case-insensitive substring filter so only
  glossary entries actually present in the text are sent) and
  `build_completeness_prompt` (matches the documented completeness-check
  JSON schema; only the prompt text -- scheduling/consuming it is
  finalization-orchestration work for a later phase).
- `validator.py`: `validate_translation` checking, in order, empty output,
  forbidden explanation/label prefixes, pathological repetition (a
  character-level repeated-run regex, not word-tokenized, so it works for
  non-space-delimited Japanese too), target-language plausibility (CJK
  character-ratio heuristic), preservation of numbers/dates/URLs/versions/
  identifiers extracted from the source and required verbatim in the
  translation, and extreme length ratio. Returns a machine-readable
  `reason` on failure.
- `client.py`: `VllmTranslationClient` posts an OpenAI-compatible
  `/chat/completions` request (temperature 0, top-p 1, `stream: false`,
  `chat_template_kwargs: {"enable_thinking": false}` for non-thinking mode)
  and maps HTTP 429/503 to overloaded, other non-2xx/malformed responses to
  failed, and `httpx` errors via `classify_backend_error`. Timeout/
  cancellation are the caller's responsibility (matches `FinalTranscriber`'s
  pattern), not enforced inside the client itself.
- `queue.py`: `TranslationPriority` (FINAL < RETRY < COMPLETENESS, matching
  the `docs/ARCHITECTURE.md` vLLM scheduler priority policy) and
  `TranslationQueue`, a bounded, per-priority-lane FIFO (pure/synchronous,
  matching `AckBatcher`/`OutboundBuffer`'s style) that rejects overflow on
  one lane explicitly without affecting the others, plus
  `should_skip_completeness` (the documented queue-pressure skip policy).
- `worker.py`: `FinalTranslator` runs one bounded (semaphore-limited
  concurrency), timed (`wait_for`) translation attempt per call and
  validates the result. `translate_once` never auto-retries, so a caller can
  publish `utterance.final` immediately on failure/timeout without blocking;
  `retry` is the single allowed second attempt, using a corrective prompt
  when the prior failure was a recoverable validation issue or the original
  prompt after a backend timeout/error. `apply_translation` returns a *new*
  `UtteranceFinal` with the outcome attached (does not modify or mutate
  `server.asr.worker.FinalTranscriber`'s output). `build_translation_updated`
  builds a `translation.updated` event from a later successful retry
  (raises if the outcome is not COMPLETED).

Not in this phase's scope (consistent with Phase 05/06 precedent and the
phase prompt's own scope, since the full orchestrator is explicitly
Phase 08's "Completeness and Finalization Orchestration"): actually calling
`translate_once`/`retry` from the ASR final-event path, deciding *when* a
background retry runs and publishing its `translation.updated` over a real
socket, a live consumer draining `TranslationQueue`, and any completeness
-classification consumer (only the prompt builder and the queue's
completeness priority/skip-policy primitive are implemented here). See
"Known limitations".

## Phase 08 deliverables

Completeness and finalization orchestration
(`server/orchestration/`, `server/translation/completeness.py`), composing
every component built in Phases 04-07 into the full documented pipeline
(`docs/ARCHITECTURE.md`: VAD -> partial ASR -> final ASR -> translation ->
final event) plus this phase's own deterministic heuristic checker. As with
every prior phase, this is composable/testable domain logic, not yet wired
into the live gateway WebSocket ingest path -- see "Known limitations".

- `server/orchestration/heuristics.py`: `HeuristicConfig`
  (language-specific sentence-ending punctuation and ending-signal
  vocabularies, `min_stable_speech_ms`, `max_unstable_tail_chars`, with a
  `from_settings` mapping) and `evaluate_heuristic`, the deterministic
  completeness checker. Evaluates, in order: an empty stable text (definite
  incomplete), an unstable tail longer than the configured threshold
  (definite incomplete -- ASR is still actively catching up, so no
  confident decision can be made), sentence-ending punctuation with
  sufficient confirmed speech duration (definite complete), a
  language-specific ending-signal word/phrase with sufficient speech
  duration (definite complete), else ambiguous with a deterministic
  (incomplete) fallback value. "Stable duration" is interpreted as the
  utterance's own confirmed `speech_ms` (a very short burst is unreliable
  even with a punctuation match) -- documented explicitly in the module
  docstring since the phase prompt does not prescribe an exact algorithm.
- `server/orchestration/types.py`: `CompletenessConfig` (enabled/timeout/
  skip-queue-depth/max-tokens/min-confidence, with a `from_settings`
  mapping to the new `completeness_*` settings below) and the
  `PublishEvent`/`OrchestratorEvent` type aliases for the orchestrator's
  event-publishing sink.
- `server/translation/completeness.py`: `CompletenessClassifier` -- the
  optional low-priority Qwen completeness check (docs/TRANSLATION.md).
  Reuses the existing `TranslationClient` protocol and
  `build_completeness_prompt` (Phase 07); bounded by a strict
  `asyncio.wait_for` timeout and a small `max_tokens`. Parses the model's
  JSON response (with one bounded fallback extraction if the model wrapped
  it in extra text/markdown despite instructions); any failure -- timeout,
  backend error, invalid JSON, wrong types, or a `confidence` that is
  actually a `bool` (a Python subtlety: `bool` is a subclass of `int`) --
  yields an explicit "unknown" outcome (`complete=None`) rather than
  raising, so the caller always has a clean fallback path.
- `server/orchestration/pipeline.py`: `UtteranceOrchestrator` -- the full
  per-session pipeline. Owns one `UtteranceSegmenter` per registered stream
  (VAD state is inherently per-stream) and shares one `PartialTranscriber`,
  `PartialDecodeScheduler`, `FinalTranscriber`, `FinalTranslator`,
  `CompletenessClassifier` and `TranslationQueue` across every stream in
  the session (matching one real ASR/translation backend serving multiple
  streams). Frame ingestion (`ingest_frame`) and partial-decode ticking
  (`run_due_partial_decodes`) are caller-driven (matches
  `PartialDecodeScheduler`'s existing time-injected style); `flush_stream`
  forces finalization for `client_flush`/`session_end`/
  `device_reconfigured`. Soft silence triggers a background completeness
  *decision* (heuristic first; only an ambiguous verdict -- and only when
  completeness checking is enabled and the shared `TranslationQueue`'s
  current depth is below `completeness_skip_queue_depth`
  (`should_skip_completeness`, Phase 07) -- consults the classifier) rather
  than blocking or auto-finalizing; hard silence and max-utterance duration
  remain handled synchronously inside `UtteranceSegmenter` itself
  (unchanged from Phase 04). On finalization, runs final ASR then one
  bounded translation attempt before publishing `utterance.final`
  (translation failure never blocks the transcription publish -- Phase 07's
  documented policy); a failed attempt schedules the single allowed retry
  in the background, publishing `translation.updated` if it later
  succeeds. At most the last two finalized sentences per stream are kept as
  translation context (`MAX_CONTEXT_SENTENCES`, Phase 07), captured once
  before the retry request is built so a retry's context never includes
  the utterance being retried.
  - **Race safety** (this phase's own required outcome -- "one utterance
    cannot finalize twice"): each utterance carries a monotonically
    increasing "pending generation" counter, bumped on every soft silence
    (a new decision), resumed speech (invalidates any decision in flight)
    and finalization for any reason (invalidates; already finalized). A
    soft-silence decision only acts (calling `segmenter.flush` with
    `semantic_complete`) if, at the moment it is ready to act, its captured
    generation still matches the current one for that utterance id *and*
    the segmenter still reports that same utterance as open -- both are
    re-checked immediately before acting, after any `await` (e.g. the
    completeness model round trip). Verified by
    `test_no_double_finalize_when_hard_silence_races_pending_decision` and
    `test_pause_resume_discards_stale_decision_no_early_finalize` in
    `tests/test_orchestration_pipeline.py`, which deliberately construct
    the race (a still-pending decision, then a competing hard-silence
    finalize or a speech resume) and assert exactly one `utterance.final`
    is ever published, with the correct `final_reason`.
  - The `TranslationQueue` (Phase 07, previously unconsumed) is used here
    as a live in-flight-work depth tracker for queue-pressure purposes: one
    placeholder item is `put` into the relevant priority lane for the
    duration of each final/retry/completeness attempt and `get` back out
    when it completes, so `qsize()` reflects real concurrent load across
    all streams in the session. This is a deliberately lighter-weight design
    than a full generic priority dispatcher (not required by this phase's
    outcomes): priority ordering for concurrently-*queued* work is achieved
    because `FinalTranslator`/`CompletenessClassifier` calls are dispatched
    as soon as they are ready and then wait on `FinalTranslator`'s own
    internal semaphore, whose FIFO admission order matches dispatch order;
    building a true generic drain-loop dispatcher is left as future work if
    a later phase's real-time gateway wiring needs it.
- Small, additive accessors needed by the above, backward compatible with
  Phase 04/06's existing tests: `UtteranceSegmenter.speech_ms` (read-only
  property exposing the existing internal counter) and
  `PartialTranscriber.current_text()` (exposes the last-published stable/
  unstable text without forcing a new decode).
- `shared/settings.py` + `.env.example`: added `completeness_max_tokens`,
  `completeness_min_confidence`, `completeness_heuristic_min_speech_ms`,
  `completeness_heuristic_max_unstable_tail_chars` and
  `translation_queue_capacity_per_priority`.

Not in this phase's scope (consistent with every prior phase's precedent
and this phase's own required outcomes, which do not mention the gateway or
WebSocket): wiring `UtteranceOrchestrator` into the live
`server/transport/gateway.py` WebSocket ingest path (feeding real released
audio frames in, sending published events out over the socket), and a
real-time asyncio loop driving `run_due_partial_decodes` off a wall clock.
See "Known limitations".

## User-provided hardware results

- WINDOWS-AUDIO-001 (PASSED, 2026-08-10): see `USER_RESULTS.md`. Unchanged by
  Phase 05.
- GPU-ASR-001 (PASSED, 2026-08-10): see `USER_RESULTS.md`. ASR GPU host
  confirmed capable (H100 80GB, CUDA 13.0, Python 3.11.13).
- GPU-ASR-002 (INCONCLUSIVE, 2026-08-11): see `USER_RESULTS.md`.
  `faster-whisper` 1.2.1 installed; the action's `torch` check was invalid
  (not a project dependency) and proved nothing about GPU readiness.
  Superseded by GPU-ASR-003.
- GPU-ASR-003 (PASSED, 2026-08-11): see `USER_RESULTS.md`. `ctranslate2`
  4.8.1 sees 1 CUDA device on the H100; real venv path confirmed as
  `/workspace/meetting-translator/.venv-asr`. `libcudnn` not seen via
  `ldconfig` — not disqualifying per this action's own criteria, but left as
  an open question for GPU-ASR-004's real model load.
- GPU-ASR-004 (PASSED, 2026-08-11): see `USER_RESULTS.md`. `large-v3`
  (revision `edaa852ec7e145841d8ffdb056a99866b5f0a478`) loaded (3.66s) and
  decoded a synthetic tone (0.29s) with no CUDA/cuDNN/cuBLAS error, resolving
  GPU-ASR-003's open cuDNN question.
- GPU-ASR-005 (PASSED, 2026-08-12): see `USER_RESULTS.md`. No exception,
  `segments > 0` for both languages, fluent well-formed vi/ja text; user
  confirmed both transcripts roughly accurate.
- GPU-TRANSLATE-001 (PASSED, 2026-08-12): see `USER_RESULTS.md`. Same H100
  80GB host as ASR (single GPU, shared, not separate as recommended); ample
  RAM/CPU/disk; no errors.
- GPU-TRANSLATE-002 (PASSED, 2026-08-12): see `USER_RESULTS.md`.
  `Qwen/Qwen3.6-27B-FP8` downloaded (revision
  `e89b16ebf1988b3d6befa7de50abc2d76f26eb09`, ~29-30.9 GB, 8m11s); no
  exception.
- GPU-TRANSLATE-003 (FAILED, 2026-08-12): see `USER_RESULTS.md`. vLLM
  launch crashed on a third-party `flashinfer` `array.array[int]`
  `TypeError` during `torch.compile` backend setup; root-caused, not
  project-caused. Retried as GPU-TRANSLATE-004 with `--enforce-eager`.
- GPU-TRANSLATE-004 (FAILED, 2026-08-12): see `USER_RESULTS.md`.
  `--enforce-eager` fixed the targeted crash (model construction and KV
  -cache sizing succeeded), but a second import path hit the identical
  `flashinfer` `array.array[int]` bug.
- GPU-TRANSLATE-005 (PASSED, 2026-08-12): see `USER_RESULTS.md`. Direct
  `flashinfer` patch resolved the bug; server reached full startup;
  72237/81559 MiB GPU memory in use; no traceback.
- GPU-TRANSLATE-006 (PASSED, 2026-08-12): see `USER_RESULTS.md`. `/health`
  returned 200; `/v1/models` confirmed `id=qwen3.6-27b-translate` with
  matching `root`/`max_model_len`. No error.
- GPU-TRANSLATE-007 (PASSED, 2026-08-12): see `USER_RESULTS.md`. Real
  JA->VI and VI->JA translation requests through the project's own prompt
  -building code both returned 200 OK, no exception; outputs plausible and
  correctly scripted per Claude's linguistic assessment (see "Known
  limitations" for the caveat that the user did not separately state an
  explicit plausibility verdict). Last of Phase 07's staged GPU
  checkpoints.

## Known limitations

- `whisper_device` defaults to `cuda`; CPU-only local runs do not load ASR.
- GPU dependency group: the host is confirmed capable (GPU-ASR-001 PASSED),
  `faster-whisper` 1.2.1 is installed on the GPU host venv (GPU-ASR-002),
  `ctranslate2` confirms the GPU is visible and enumerable (GPU-ASR-003
  PASSED), and a real `large-v3` model load + decode succeeded with no
  CUDA/cuDNN/cuBLAS error (GPU-ASR-004 PASSED), and GPU-ASR-005 confirmed the
  real adapter produces plausible transcripts on real vi/ja speech, per the
  user's own judgment (PASSED 2026-08-12). The ASR adapter itself is now
  hardware-verified end-to-end on a two-sample plausibility basis; scored
  accuracy/latency benchmarking across more samples has not been done.
- `WhisperAsrModel` is implemented, hardware-confirmed for model-load/decode
  (GPU-ASR-004), and hardware-confirmed for real-speech plausibility in both
  target languages (GPU-ASR-005, user-judged roughly accurate). It is still
  excluded from the CPU suite (needs the GPU/model weights). Scored accuracy
  and latency across a larger sample set remain unmeasured/future work.
- The `FinalTranscriber` is not yet wired into the gateway/VAD ingest path;
  connecting utterance finalization to real audio and emitting `utterance.final`
  over the socket is integrated in a later phase. Translation is not attached
  yet (events carry `translation=null` / status `pending`).
- The gateway validates, orders and acknowledges audio but does not yet forward
  released frames into the `UtteranceSegmenter`; wiring VAD into the ingest path
  (and running probabilities off the event loop) lands with the ASR phases.
- `PartialTranscriber`/`PartialDecodeScheduler` (Phase 06) are implemented and
  unit-tested with a scripted model, but not yet wired into the gateway/VAD
  ingest path or driven by a live asyncio loop — same status as
  `FinalTranscriber`. `transcription.partial` events are not yet actually
  published over a real socket. Not hardware-verified: `PartialTranscriber`
  uses the same `WhisperAsrModel`/`AsrModel` interface already
  hardware-verified for final decoding (GPU-ASR-004/005), but no GPU-side
  smoke test has exercised `partial_beam_size`/the partial code path
  specifically; that would be natural follow-up manual work if/when this
  phase's output is integrated, not required to close Phase 06's own scope
  (which is local domain logic per `prompts/phases/06_WHISPER_PARTIAL.md`).
- **Bug fix: client reconnect cancellation race** (2026-08-11, investigated
  and fixed at the user's request, separate from Phase 06's own scope).
  `tests/test_transport_sender.py::test_run_reconnects_and_resends_pending`
  (Phase 03) was timing out deterministically (2s) in this environment;
  reproduced in a minimal script with no project code involved. Root cause:
  `AudioSender._serve()` (`client/transport/sender.py`) cancelled its two
  pump tasks exactly once each in a `finally` block. A single
  `Task.cancel()` call can race with the task's currently-awaited future
  resolving just beforehand and be silently swallowed — a documented
  asyncio subtlety, not a Windows-only bug, though it manifested here on
  this platform/loop's scheduling timing — leaving `_pump_outgoing` running
  forever instead of stopping, so `asyncio.gather()` in the `finally` block
  never returned and the whole reconnect loop hung. Fixed by extracting a
  `_cancel_and_wait` helper that retries `cancel()` in a loop until every
  task actually finishes, instead of a single fire-and-forget cancel. Local
  snapshot `.local_backups/20260811T182415Z_sender-cancel-race-fix.zip`
  taken before the change. Verified: the previously-hanging test now passes
  in 0.117s; full suite is 187 passed / 0 failed / 2 deselected; `ruff
  format`/`ruff check`/`mypy` remain clean.
- `SileroVadModel` is implemented but unverified: it is excluded from the CPU
  suite and requires `torch`/`silero_vad` weights, so real VAD accuracy is not
  yet hardware-verified. Segmentation logic is verified with scripted
  probabilities only.
- Translation (Phase 07) is implemented and unit-tested (scripted client +
  `httpx.MockTransport`; no real vLLM), and is now verified end-to-end with
  a real translation request: `GPU-TRANSLATE-001` through
  `GPU-TRANSLATE-007` all PASSED 2026-08-12 -- the server is running,
  reached full startup, answers OpenAI-compatible requests, and a real
  JA->VI/VI->JA translation request through the project's own
  prompt-building code returned plausible, correctly-scripted output for
  both directions with no exception. Caveat: the JA/VI plausibility
  judgment for `GPU-TRANSLATE-007` was made by Claude (fluent in both
  languages) from the raw output, since the user's report did not include
  a separate explicit first-person verdict the way `GPU-ASR-005` did ("yes,
  the printed text is a roughly accurate rendering"); if a native speaker's
  review later disagrees, this should be revisited. `VllmTranslationClient`
  itself is now HARDWARE_VERIFIED against real hardware; wiring it into the
  live gateway/VAD/ASR pipeline and scored accuracy/latency benchmarking
  remain separate, not-yet-started work (Phase 08 and later).
- The `flashinfer` package installed alongside `vllm==0.27.1` (unpinned
  `pip install vllm`) had a real bug: `flashinfer/comm/fd_exchange.py`
  used `array.array[int]` as a type annotation, which always raises
  `TypeError` at import time since `array.array` has no
  `__class_getitem__`. This surfaced via multiple, independent vLLM code
  paths that import `flashinfer.comm` unconditionally (confirmed two:
  `torch.compile` backend setup via `AllReduceFusionPass`, and
  `kernel_warmup`'s unconditional MiniMax-M3 warmup import), even though
  this is a single-GPU deployment of an unrelated model (Qwen3.5) where
  neither needed to run. `--enforce-eager` (GPU-TRANSLATE-004) fixed only
  the first path; `GPU-TRANSLATE-005` patched the broken line directly in
  the installed package (quoting the invalid annotation so it is never
  evaluated -- no behavior change), which fixed every remaining import
  path at once and the server now starts successfully. This is a local,
  venv-scoped workaround (lost on reinstall/upgrade of `flashinfer`/`vllm`
  in that venv), not a permanent fix; the real fix would be a patched
  upstream `flashinfer` release, not yet identified/pinned -- not
  investigated further since the direct patch is sufficient to unblock
  functional verification.
- The translation GPU host has only one GPU (H100 80GB), and it is the
  *same* GPU already used for ASR (confirmed by `GPU-TRANSLATE-001`), not a
  separate one as `docs/ARCHITECTURE.md` recommends ("do not assume Whisper
  large-v3 and Qwen3.6-27B-FP8 can safely coexist on one 48 GB GPU under
  production load" -- written with a 48 GB GPU in mind; this is 80 GB, with
  meaningful estimated headroom, but real concurrent-load co-location has
  not been verified). Flagged for the user's awareness in
  `USER_RESULTS.md`; not currently blocking, since the model download step
  does not depend on the final co-location decision.
- **Superseded by Phase 08** (kept for history; see "Phase 08 deliverables"
  above for the current state): translation used to have no consumer/
  scheduler at all, and the completeness-check prompt had no classifier
  consuming it. `UtteranceOrchestrator` now calls
  `FinalTranslator.translate_once`/`retry`, schedules the retry in the
  background and publishes `translation.updated`, and
  `CompletenessClassifier` now actually calls vLLM to classify semantic
  completeness for ambiguous soft-silence cases. What remains genuinely
  not-yet-done is captured in the next two bullets.
- `UtteranceOrchestrator` (Phase 08) is implemented and integration-tested
  (`ScriptedAsrModel`/`ScriptedTranslationClient` fakes; no GPU/model
  weights) but, consistent with every prior phase's precedent, is **not
  wired into the live gateway WebSocket ingest path**: nothing currently
  constructs an `UtteranceOrchestrator` from `server/app.py`, feeds it
  released audio frames from `server/transport/gateway.py`, drives
  `run_due_partial_decodes` off a real wall-clock timer, or sends its
  published events back out over a real socket. The gateway still only
  validates, orders and acknowledges audio (Phase 03); VAD, ASR, partial
  transcription and translation all still run only in tests, not in the
  live request path. Wiring this into the gateway is not called for by
  this phase's own required outcomes (which do not mention the gateway or
  WebSocket) and has not been assigned to any later phase's prompt file
  either (Phases 09-11 cover the client UI, reliability/security/
  observability, and end-to-end tests/packaging) -- it should be raised
  with the user explicitly before being started, per the standing "do not
  proceed to another phase without direction" instruction.
- The completeness-check JSON schema/prompt (`CompletenessClassifier`) has
  never been sent to the real vLLM server: Phase 07's `GPU-TRANSLATE-007`
  hardware-verified the *translation* prompt path through
  `VllmTranslationClient`, but this phase's *new* completeness prompt
  (`{"complete": bool, "confidence": float}` JSON, via the same client)
  has only been exercised against local fakes. Whether the real
  Qwen3.6-27B-FP8 deployment reliably returns valid, schema-matching JSON
  for this prompt (as opposed to prose, markdown-wrapped JSON, or a
  refusal) is unverified. This is a lightweight, well-scoped follow-up
  manual action (reusing the already-running server from
  `GPU-TRANSLATE-005`, no new download/launch) that can be prepared on
  request; it was not staged automatically since it was not required to
  complete this phase's own local scope.
- Only `StaticTokenAuthenticator` (development) is provided; a production JWT
  authenticator implementing the `Authenticator` interface is future work.
- `WebSocketClientTransport` requires the `websockets` package (client/server
  extras); it is imported lazily and covered by unit tests via a fake transport
  rather than a live socket.

## Next action

Phase 08 (Completeness and finalization orchestration) is implemented and
LOCAL_VERIFIED, per `prompts/phases/08_COMPLETENESS_ORCHESTRATION.md`'s
required outcomes: the deterministic heuristic checker (punctuation, stable
speech duration, unstable tail, configurable language-specific ending
signals); soft silence triggering a decision rather than automatic
blocking; hard silence, max utterance, client flush, session end and
device reconfiguration all forcing finalization; the optional low-priority
Qwen completeness JSON request for ambiguous soft-silence cases only,
gated by a strict timeout, JSON/schema validation and queue-pressure
skipping; a timeout/invalid-output/overload result producing an explicit
"unknown" outcome that falls back to the deterministic heuristic verdict;
a race-safe speaking-to-finalizing transition (verified by two dedicated
tests deliberately constructing the race); the full orchestrator (VAD ->
partial ASR -> final ASR -> translation -> final event); and integration
tests for pause-resume, semantic completion, hard silence, completeness
timeout and concurrent streams. All local checks pass (291 passed, 0
failed, 2 deselected; ruff format/check and mypy clean).

No GPU manual action was required to complete this phase's own scope (all
of it is pure/composed domain logic tested against fakes). Two hardware
-related gaps are flagged in "Known limitations" for awareness, not
blocking this phase's completion: (1) the completeness-check JSON
prompt/schema has never been sent to the real vLLM server (only the
existing translation prompt path was hardware-verified, in Phase 07) --
available as a lightweight follow-up manual action on request; (2)
`UtteranceOrchestrator` is not wired into the live gateway WebSocket
ingest path, and no later phase's prompt file currently assigns that
wiring work either.

Per the original instruction for this phase ("Do not proceed to another
phase"), Claude is stopping here. Do not begin Phase 09 (or any other
phase), the optional completeness-JSON hardware verification, or gateway
-wiring work without the user's explicit direction. Take a local snapshot
first (`python scripts/local_backup.py --label <name>`) before starting
whichever the user chooses next -- and take it *before* editing this time
(see the process-oversight note under "Latest local snapshot" above).

No manual action is currently WAITING_FOR_USER.
