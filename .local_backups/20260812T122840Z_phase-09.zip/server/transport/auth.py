"""Authentication interface for the WebSocket gateway.

The gateway authenticates each connection through an :class:`Authenticator`.
A functional development implementation (:class:`StaticTokenAuthenticator`) is
provided. Production deployments supply a JWT-validating authenticator by
implementing the same interface (validating a signed token against
``jwt_public_key_path``/issuer/audience); no such validator is shipped here to
avoid embedding placeholder cryptography.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field


@dataclass(frozen=True)
class AuthContext:
    """Result of a successful authentication."""

    client_id: str
    subject: str
    claims: dict[str, str] = field(default_factory=dict)


class AuthError(Exception):
    """Raised when authentication fails.

    The message is safe for logging but must not contain the raw token.
    """


class Authenticator(ABC):
    """Interface implemented by concrete authenticators.

    Implementations must be side-effect free with respect to the token value and
    must never log or echo the raw credential.
    """

    @abstractmethod
    def authenticate(self, *, token: str | None, client_id: str) -> AuthContext:
        """Validate ``token`` for ``client_id`` or raise :class:`AuthError`."""
        raise NotImplementedError


class StaticTokenAuthenticator(Authenticator):
    """Development authenticator using a shared static token.

    - When ``expected_token`` is empty and ``allow_anonymous`` is true, any
      client is accepted (development convenience only).
    - When ``expected_token`` is set, the presented token must match it exactly
      using a constant-time comparison.
    """

    def __init__(self, *, expected_token: str = "", allow_anonymous: bool = True) -> None:
        self._expected_token = expected_token
        self._allow_anonymous = allow_anonymous

    def authenticate(self, *, token: str | None, client_id: str) -> AuthContext:
        if not client_id:
            raise AuthError("client_id is required")

        if not self._expected_token:
            if self._allow_anonymous:
                return AuthContext(client_id=client_id, subject=client_id, claims={"dev": "true"})
            raise AuthError("authentication required")

        if token is None:
            raise AuthError("missing token")
        if not _constant_time_equals(token, self._expected_token):
            raise AuthError("invalid token")
        return AuthContext(client_id=client_id, subject=client_id, claims={"dev": "true"})


def _constant_time_equals(left: str, right: str) -> bool:
    """Constant-time string comparison to avoid leaking length/content timing."""
    import hmac

    return hmac.compare_digest(left, right)
