# Manual Actions

Claude ghi các thao tác mà người dùng cần thực hiện tại đây.

## Pending actions

None. `GPU-TRANSLATE-007` (below) was the last staged GPU checkpoint for
Phase 07; no further translation manual action is currently pending.

## Completed actions

### Action ID: GPU-TRANSLATE-007

- Status: PASSED (2026-08-12)
- Result summary: Both requests returned `200 OK` with no
  exception/traceback. JA->VI: source "来週のリリースについて確認したいで
  す。" -> translated "Tôi muốn xác nhận về bản phát hành vào tuần tới." VI
  ->JA: source "Tôi muốn xác nhận về đợt phát hành vào tuần tới." ->
  translated "来週のリリースについて確認したいのですが。" Both outputs are
  non-empty, correctly scripted (Vietnamese with diacritics; Japanese
  kana/kanji), carry no forbidden-prefix label and show no pathological
  repetition. vLLM engine log confirms real generation occurred (non-zero
  generation throughput, `GPU KV cache usage: 0.5%`) rather than an empty/
  cached response. Claude's own linguistic assessment (fluent in both
  languages): both translations are accurate and natural renderings of the
  source meaning ("I'd like to confirm about next week's release") in each
  direction. Note: the user's raw command output did not include an
  explicit first-person plausibility verdict (unlike `GPU-ASR-005`'s "yes,
  the printed text is a roughly accurate rendering"); this PASSED
  determination rests on the technical success indicators plus Claude's
  linguistic read of the output, not an explicit user judgment call. Flag
  to the user if either translation reads as wrong to a native speaker.
- Purpose: First real-translation, real-code-path check -- the last of
  this phase's staged GPU checkpoints. Exercised the project's own prompt
  builder (`server/translation/prompts.py`) against the running vLLM
  server in both directions using `TranslationConfig`'s documented
  defaults (temperature 0, top-p 1, non-thinking mode).
- Run on: Same host as `GPU-TRANSLATE-001`-`GPU-TRANSLATE-006`.
- Note: This closes out Phase 07's staged GPU checkpoint sequence. No
  further translation-specific manual action is currently pending; wiring
  `FinalTranslator` into the live gateway/VAD/ASR pipeline and any
  completeness-classification consumer remain Phase 08's scope.

### Action ID: GPU-TRANSLATE-006

- Status: PASSED (2026-08-12)
- Result summary: `/health` returned `http_status=200`. `/v1/models`
  returned a well-formed OpenAI-compatible listing:
  `id=qwen3.6-27b-translate`, `root=/workspace/meetting-translator/models/Qwen3.6-27B-FP8`,
  `max_model_len=4096` -- matching the launch config exactly. No error,
  timeout or unexpected status.
- Purpose: First HTTP-level confirmation the running server answers
  OpenAI-compatible requests and serves the expected model name.
- Run on: Same host as GPU-TRANSLATE-001-005.
- Note: See GPU-TRANSLATE-007 for the first real translation request
  through the project's own prompt-building code.

### Action ID: GPU-TRANSLATE-005

- Status: PASSED (2026-08-12)
- Result summary: Step 1 confirmed no lingering process. Step 2 (patch)
  printed `patched OK`. Steps 3-4: server started cleanly --
  "Started server process", "Waiting for application startup.",
  "Application startup complete.", "API server: HTTP server started". No
  traceback. Step 5: `nvidia-smi` reports `72237 MiB / 81559 MiB` used --
  consistent with weights (~27.67 GiB) + KV cache (~41.03 GiB) both loaded,
  no OOM.
- Purpose: Patch the broken `flashinfer` line directly (fixes every import
  path that hits it, not just the one `--enforce-eager` avoided), then
  relaunch.
- Run on: Same host as GPU-TRANSLATE-001-004.
- Note: This is the first successful vLLM server start. See
  GPU-TRANSLATE-006 for the first HTTP-level confirmation
  (`/health`, `/v1/models`) that the server actually responds and serves
  the expected model name.

### Action ID: GPU-TRANSLATE-004

- Status: FAILED (2026-08-12)
- Result summary: Real progress this time. With `--enforce-eager`, model
  construction succeeded: weights loaded in 23.7s (27.67 GiB), KV cache
  computed (41.03 GiB available, 292,522 tokens, 71.42x max concurrency at
  4096 tokens/request) -- the exact `TorchCompileWithNoGuardsWrapper` crash
  from GPU-TRANSLATE-003 did not recur. However, `EngineCore` then still
  crashed with the identical `TypeError: type 'array.array' is not
  subscriptable` in `flashinfer/comm/fd_exchange.py`, reached via a
  *different* import chain this time:
  `_initialize_kv_caches()` -> `compile_or_warm_up_model()` ->
  `kernel_warmup()` -> unconditionally imports
  `vllm.model_executor.warmup.minimax_m3_msa_warmup` (MiniMax-M3-specific
  warmup code, unrelated to the Qwen3.5 model actually being served) ->
  `vllm.model_executor.layers.fused_allreduce_gemma_rms_norm` ->
  `vllm.compilation.passes.fusion.allreduce_rms_fusion` ->
  `flashinfer.comm` -> same broken `fd_exchange.py` line.
- Purpose: Retry the vLLM launch with `--enforce-eager` to route around the
  GPU-TRANSLATE-003 crash.
- Run on: Same host as GPU-TRANSLATE-001/002/003.
- Note: Since a second, independent code path hit the identical underlying
  bug, and more such paths may exist, GPU-TRANSLATE-005 patches the actual
  broken line in the installed `flashinfer` package directly (a one-line,
  behavior-preserving fix: quoting an invalid type annotation so it is
  never evaluated) instead of continuing to chase individual import paths.

### Action ID: GPU-TRANSLATE-003

- Status: FAILED (2026-08-12)
- Result summary: `pip install vllm` (command 1) completed normally. The
  `nohup vllm serve ...` launch (command 2) crashed during model
  construction, before any GPU memory was meaningfully used for inference
  (`EngineCore failed to start`). Root cause, confirmed by reading the
  traceback plus vLLM's own source on GitHub: vLLM's `torch.compile`
  backend setup (triggered unconditionally during model construction, not
  gated by anything project-specific) imports `vllm.compilation.backends`
  -> `PostGradPassManager` -> `AllReduceFusionPass` ->
  `flashinfer.comm` -> ... -> `flashinfer/comm/fd_exchange.py`, whose
  module-level code defines a function with the return-type annotation
  `array.array[int]`. `array.array` does not support `__class_getitem__`
  (subscripting), so this raises
  `TypeError: type 'array.array' is not subscriptable` at import time,
  unconditionally -- a genuine third-party bug in the installed
  `flashinfer` package, not caused by this project's code, the model
  download, or the host environment. Commands 3-4 (log tail, `nvidia-smi`
  check) were not meaningful to run since the server process had already
  exited.
- Purpose: Install `vllm` and launch it as an OpenAI-compatible server over
  the downloaded weights via bare-process `vllm serve`.
- Run on: Same host as GPU-TRANSLATE-001/002.
- Note: See GPU-TRANSLATE-004 for the retry with `--enforce-eager`, which
  (per vLLM's own conditional logic in `vllm/compilation/decorators.py`)
  skips the exact code path that imports the broken `flashinfer.comm`
  module.

### Action ID: GPU-TRANSLATE-002

- Status: PASSED (2026-08-12)
- Result summary: Downloaded `Qwen/Qwen3.6-27B-FP8` (80 files, ~8m11s,
  ~21.6-193MB/s) to
  `/workspace/meetting-translator/models/Qwen3.6-27B-FP8`. Resolved
  revision `e89b16ebf1988b3d6befa7de50abc2d76f26eb09`. `du -sh` reports 29G
  on disk (consistent with the officially published ~30.9 GB; the
  difference is normal GiB-vs-GB/filesystem-accounting variance, not a
  partial download -- the download tool itself reported "30.9GB / 30.9GB"
  complete). No exception/traceback.
- Purpose: Download the official weights into a persistent path, in a new
  `.venv-translate` kept separate from `.venv-asr`, and record the
  resolved revision/size.
- Run on: Same host as GPU-TRANSLATE-001.
- Note: See GPU-TRANSLATE-003 for installing and launching vLLM over these
  weights.

### Action ID: GPU-TRANSLATE-001

- Status: PASSED (2026-08-12)
- Result summary: Run on `/workspace/meetting-translator` -- the same
  physical host as the ASR GPU work (`GPU-ASR-001`-`GPU-ASR-005`), single
  GPU: NVIDIA H100 80GB HBM3, 0 MiB used, driver 580.82.07, CUDA (driver)
  13.0, nvcc 12.8. Host: 128 CPUs, 1.5 TiB RAM (596 GiB free). Disk:
  `/workspace` PVC 300G total, 155G avail. Step 5 (Docker check) was
  intentionally skipped -- user intends the bare-process `vllm serve`
  launch path, which does not need Docker. No errors observed.
- Purpose: Inspect the translation GPU host (read-only) to confirm it can
  host `Qwen3.6-27B-FP8` via vLLM before any download or launch. Installs
  nothing, downloads nothing, runs no inference.
- Run on: Translation GPU host (confirmed same host as ASR).
- Note: This host has only one GPU (H100 80GB), the same one already used
  for ASR -- see the follow-up analysis in `USER_RESULTS.md` for why 80GB
  is treated as sufficient headroom for both models despite
  `docs/ARCHITECTURE.md`'s general caution against assuming Whisper and
  Qwen safely coexist on one GPU. See GPU-TRANSLATE-002 for the model
  download.

### Action ID: GPU-ASR-005

- Status: PASSED (2026-08-12)
- Result summary: Ran against real `vi_sample.wav` (28s) and `ja_sample.wav`
  (20s). No exception for either language; `segments > 0` for both (7 and
  8); output was fluent, coherent text in each language. User confirmed:
  "yes, the printed text is a roughly accurate rendering of what i said" —
  satisfying the action's ground-truth plausibility criterion for both
  clips. GPU ASR is now hardware-verified for the ASR adapter itself
  (real speech, real project code path, both target languages).
- Purpose: First real-speech, real-code-path check. Exercises the project's
  own `WhisperAsrModel` adapter (`server/asr/whisper.py`) — not the bare
  `faster_whisper` library — against short genuine speech samples in both
  target languages (`vi`, `ja`), using the project's documented `AsrConfig`
  defaults from `.env.example` (`large-v3`, `cuda`, `float16`,
  `final_beam_size=3`, `temperature=0.0`, `condition_on_previous_text=True`).
  This is a plausibility check ("is the transcribed text roughly what was
  said"), not a scored accuracy benchmark — that is separate, later work.
- Run on: GPU ASR server, inside the existing venv at
  `/workspace/meetting-translator/.venv-asr`, from the project root
  `/workspace/meetting-translator` (so `server`/`shared` import correctly).
- Prerequisites:
  - GPU-ASR-004 PASSED (confirmed below): `large-v3` loads and decodes on
    this GPU with no CUDA/cuDNN/cuBLAS error.
  - Two short (~5-10s) WAV recordings of clear, real speech: one Vietnamese,
    one Japanese, each mono / 16-bit / 16000 Hz. The easiest way to get a
    correctly-formatted file is the already-verified capture tool from
    WINDOWS-AUDIO-001, run on your Windows client while actually speaking a
    short sentence:
    `python -m client.audio.wav_cli capture --source microphone --seconds 8 --out vi_sample.wav`
    (repeat in Japanese for `ja_sample.wav`). Any other mono/16-bit/16000 Hz
    WAV of clear speech works too.
  - Those two WAV files copied onto the GPU host into
    `/workspace/meetting-translator/` as `vi_sample.wav` and `ja_sample.wav`
    (transfer method is up to you / your normal way of copying files onto
    this pod — not prescribed here).
- Safety notes: Reads two local WAV files and runs two inference calls
  through the already-installed venv. Does not modify the venv, drivers,
  containers, services, firewall or permissions, and downloads nothing new.
  The recorded speech is a throwaway test utterance, not real meeting
  content — please say something innocuous (e.g. count or read a sentence
  aloud) since the transcribed text will be pasted back into this chat, and
  avoid recording anything sensitive.

Commands (run on the GPU ASR host, with the venv active, from the project root):

```bash
source /workspace/meetting-translator/.venv-asr/bin/activate
cd /workspace/meetting-translator

# 1. Write a script that uses the project's real ASR adapter and config,
#    not bare faster_whisper.
cat > /tmp/asr_real_speech_test.py << 'EOF'
import wave
from server.asr.types import AsrConfig, AsrRequest
from server.asr.whisper import WhisperAsrModel
from shared.protocol.enums import Language


def load_pcm(path: str) -> bytes:
    with wave.open(path, "rb") as wf:
        if wf.getnchannels() != 1 or wf.getsampwidth() != 2 or wf.getframerate() != 16000:
            raise ValueError(
                f"{path}: expected mono/16-bit/16000Hz, got "
                f"channels={wf.getnchannels()} sampwidth={wf.getsampwidth()} "
                f"framerate={wf.getframerate()}"
            )
        return wf.readframes(wf.getnframes())


config = AsrConfig(
    model="large-v3",
    device="cuda",
    compute_type="float16",
    final_beam_size=3,
    temperature=0.0,
    condition_on_previous_text=True,
)
model = WhisperAsrModel(config)

for language, filename in [(Language.VIETNAMESE, "vi_sample.wav"), (Language.JAPANESE, "ja_sample.wav")]:
    audio = load_pcm(filename)
    request = AsrRequest(
        audio=audio,
        language=language,
        beam_size=config.final_beam_size,
        temperature=config.temperature,
        condition_on_previous_text=config.condition_on_previous_text,
    )
    result = model.transcribe(request)
    print(f"--- {language.value} ({filename}) ---")
    print(f"duration_ms={result.duration_ms}")
    print(f"segments={len(result.segments)}")
    print(f"text={result.text!r}")
EOF

# 2. Run it, keeping stderr visible for any error.
PYTHONPATH=/workspace/meetting-translator python /tmp/asr_real_speech_test.py
```

Expected success indicators:
- No exception/traceback for either language.
- `segments` > 0 for both.
- The printed `text` for `vi_sample.wav` is plausible, readable Vietnamese
  (with diacritics) roughly matching what was actually said; the printed
  `text` for `ja_sample.wav` is plausible, readable Japanese (kana/kanji)
  roughly matching what was actually said. You are the ground truth judge —
  this is a rough sanity check, not automated scoring.

Expected artifacts:
- None permanent. `/tmp/asr_real_speech_test.py` is temporary.

Rollback or cleanup:
- `rm /tmp/asr_real_speech_test.py`. Delete the WAV fixture files if desired
  (`vi_sample.wav`, `ja_sample.wav`).

Return to Claude (with secrets/sensitive paths redacted):
- Exact commands used and their exit status.
- Full stdout for both languages (the printed `text` fields), plus your own
  judgment of whether each is a roughly correct/plausible transcription of
  what you actually said.
- Any exception/traceback.

Received output: No exception for either language. `vi_sample.wav`:
`duration_ms=28000 segments=7`, fluent coherent Vietnamese (company profile
passage). `ja_sample.wav`: `duration_ms=20000 segments=8`, fluent coherent
Japanese (textbook sentence-pattern examples). User confirmed (2026-08-12):
"yes, the printed text is a roughly accurate rendering of what i said."
Full text recorded in `USER_RESULTS.md`.

Note: This was a plausibility check on two short clips, not a scored
accuracy benchmark. Broader accuracy/latency benchmarking across more
samples, and wiring `FinalTranscriber` into the live gateway/VAD path, are
separate, later work.

### Action ID: GPU-ASR-004

- Status: PASSED (2026-08-11)
- Result summary: `large-v3` loaded in 3.66s and decoded a synthetic 3s tone
  in 0.29s with no exception — real model weights, real GPU compute, no
  CUDA/cuDNN/cuBLAS load error. This resolves the open question left by
  GPU-ASR-003 (missing `libcudnn` in `ldconfig`): whatever the dependency
  resolution path, it works end-to-end on this host. Detected language/
  probability and segment count on the tone are not meaningful (no real
  speech in the input) and were expected to be arbitrary. Model revision
  recorded: `Systran/faster-whisper-large-v3` @
  `edaa852ec7e145841d8ffdb056a99866b5f0a478`, 3090835702 bytes (~2.88 GiB) on
  disk.
- Purpose: First real GPU decode (model load + one inference call) to prove
  the actual codepath works, not just CUDA device enumeration.
- Run on: GPU ASR server, `/workspace/meetting-translator/.venv-asr`.
- Note: See GPU-ASR-005 for the first real-speech, real-adapter-code test.

### Action ID: GPU-ASR-003

- Status: PASSED (2026-08-11)
- Result summary: `ctranslate2` 4.8.1 installed and `cuda_device_count()`
  returned 1 — CTranslate2 (the library `faster-whisper` actually delegates
  GPU execution to) successfully sees the H100. Active Python/pip confirmed
  inside `/workspace/meetting-translator/.venv-asr` (note: the real venv path
  has an extra path segment — `meetting-translator`, not `/workspace`
  directly — earlier actions' assumed path is corrected in GPU-ASR-004).
  `faster-whisper` 1.2.1 and `ctranslate2` 4.8.1 both present in `pip list`.
  `nvidia-smi` shows the same idle H100 as GPU-ASR-001. `libcudart`/
  `libcublas`/`libcublasLt` resolved via `ldconfig`; no `libcudnn` entry
  appeared in that listing, but per this action's own stated success
  criteria a missing `ldconfig` match is only disqualifying when
  `cuda_device_count` is 0, which it was not — so this is not treated as a
  failure here. It is flagged as an open risk for GPU-ASR-004 (first real
  model load/decode) to either confirm is harmless (e.g. cuDNN bundled
  inside the `ctranslate2` wheel rather than resolved via system
  `ldconfig`) or surface as a load-time error.
- Purpose: Re-check GPU visibility through the library faster-whisper
  actually uses (`ctranslate2`), after GPU-ASR-002's flawed `torch` check.
- Run on: GPU ASR server, `/workspace/meetting-translator/.venv-asr`.
- Note: See GPU-ASR-004 for the first real model-load/decode test that
  resolves the open cuDNN-visibility question.

### Action ID: GPU-ASR-002

- Status: INCONCLUSIVE (2026-08-11)
- Result summary: `faster-whisper` 1.2.1 installed successfully. The prepared
  diagnostic additionally tried `import torch`, which failed with
  `ModuleNotFoundError` — but this was a flaw in the action as written, not a
  real failure signal: `faster-whisper` executes inference through
  CTranslate2, and the project's `pyproject.toml` `gpu` extra pins only
  `faster-whisper>=1.0,<2` with no PyTorch requirement. GPU visibility for the
  library `faster-whisper` actually uses was not checked by this action.
  Superseded by GPU-ASR-003, which checks `ctranslate2` directly.
- Purpose: Install only the faster-whisper GPU inference stack (not the full
  `gpu` extra, since translation may run on a separate GPU per
  `docs/ARCHITECTURE.md`) into a persistent virtual environment on the ASR GPU
  host, and confirm CUDA is visible to the installed PyTorch build. Installs
  packages only; downloads no model weights and runs no inference.
- Run on: GPU ASR server (same host as GPU-ASR-001: H100 80GB, driver
  580.82.07, CUDA 13.0, Python 3.11.13, containerized/Kubernetes pod with a
  persistent `/workspace` PVC mount).
- Prerequisites:
  - GPU-ASR-001 PASSED (confirmed below).
  - Project source copied to the GPU host under `/workspace` (or another path
    on the persistent PVC, not the ephemeral container overlay, so the venv
    survives a pod restart).
  - Outbound network access to PyPI (or an internal mirror) from the host.
- Safety notes: Installs Python packages into a new, isolated virtual
  environment only. Does not touch system Python, drivers, CUDA toolkit,
  containers, services, firewall or permissions. Does not download model
  weights. Do not paste secrets, tokens or full hostnames; redact as needed.

Commands (run on the GPU ASR host, from the project root under `/workspace`):

```bash
# 1. Create a persistent virtual environment on the PVC-backed path.
python3 -m venv /workspace/.venv-asr
source /workspace/.venv-asr/bin/activate

# 2. Upgrade packaging tools.
python -m pip install --upgrade pip

# 3. Install only the ASR inference dependency (pinned per pyproject.toml's
#    `gpu` extra: faster-whisper>=1.0,<2).
pip install "faster-whisper>=1.0,<2"

# 4. Confirm the installed stack imports.
python -c "import faster_whisper; print('faster_whisper', faster_whisper.__version__)"
```

Expected artifacts:
- `/workspace/.venv-asr/` virtual environment (persistent on the PVC). No
  model weights are downloaded by this action.

Rollback or cleanup:
- `rm -rf /workspace/.venv-asr` removes the environment; no other system
  state is changed.

Note: See GPU-ASR-003 for the corrected GPU-visibility diagnostic.

### Action ID: GPU-ASR-001

- Status: PASSED (2026-08-10)
- Result summary: NVIDIA H100 80GB HBM3, 0 MiB used / 81559 MiB total, driver
  580.82.07, CUDA (driver) 13.0, nvcc 12.8 (CUDA 12.8 toolkit). Host: 128
  logical CPUs, 1.5 TiB RAM (696 GiB free). Disk: container overlay 24T
  (18T avail), persistent `/workspace` PVC mount 300G (156G avail). Python
  3.11.13. Host is a containerized/Kubernetes pod (nvidia-fabricmanager
  socket, PVC-backed `/workspace`, overlay root filesystem) rather than bare
  metal — noted for later steps so installs/venvs target the persistent PVC
  path, not the ephemeral overlay. No errors observed.
- Purpose: Inspect the user-managed ASR GPU environment (read-only) to confirm
  it can host faster-whisper large-v3 before any model install or inference is
  prepared. This action installs nothing and runs no inference.
- Run on: GPU ASR server (the host that will run faster-whisper).
- Prerequisites:
  - A shell on the ASR GPU host.
  - `nvidia-smi` available (NVIDIA driver installed).
  - Python 3.11+ available (for the version check only).
- Safety notes: Read-only inspection. Does not install packages, download
  weights, change drivers, containers, services, firewall or permissions. Do
  not paste secrets, tokens or full hostnames; redact as needed.

Commands (run on the GPU ASR host):

```bash
# 1. GPU model, VRAM, driver and CUDA runtime version.
nvidia-smi

# 2. CUDA toolkit compiler version, if present (optional).
nvcc --version 2>/dev/null || echo "nvcc not on PATH (optional)"

# 3. Host CPU/RAM summary.
#    Linux:
free -h ; nproc
#    (Windows host alternative: systeminfo | findstr /C:"Total Physical Memory")

# 4. Free disk space where model weights will live (large-v3 ~ 3 GB).
df -h .

# 5. Python version available for the ASR service.
python3 --version 2>/dev/null || python --version
```

Expected success indicators:
- Step 1 prints at least one NVIDIA GPU with its total memory, driver version
  and the CUDA version supported by the driver.
- Step 3 shows the available system RAM and CPU count.
- Step 4 shows sufficient free disk (several GB) for model weights and cache.
- Step 5 reports Python 3.11 or newer.

Expected artifacts:
- None. Read-only; no files are created.

Rollback or cleanup:
- None required; no changes are made.

Return to Claude (with secrets/sensitive paths redacted):
- Exact commands used and their exit status.
- Full stdout/stderr of steps 1 and 3-5 (step 2 optional), with any tokens,
  private hostnames or personal paths redacted.
- The `nvidia-smi` GPU model, total VRAM, driver version and CUDA version.
- Any observed error, missing tool or insufficient resource.

Note: This is inspection only. Model installation and inference are separate,
later action IDs (e.g. GPU-ASR-002+) and must not begin until this action's
output is returned and analyzed.

### Action ID: WINDOWS-AUDIO-001

- Status: PASSED (2026-08-10)
- Result summary: Device enumeration listed 8 input devices and 2 loopback
  devices. Microphone capture wrote `mic_test.wav` (158720 bytes, 248 frames,
  dropped=0). Loopback capture on device 17 wrote `loopback_test.wav`
  (159360 bytes, 249 frames, dropped=0). No errors observed.
- Purpose: Verify Windows audio device enumeration and short microphone/loopback
  WAV capture using the PyAudioWPatch backend. Confirms real devices are found
  and captured audio normalizes to mono 16 kHz PCM S16LE.
- Run on: Windows 10/11 machine with a working microphone and audio output.
- Prerequisites:
  - This project directory copied to the Windows machine.
  - Python 3.11+ available.
  - A meeting/audio app or media playing during the loopback capture so the
    loopback WAV is not silent.
- Safety notes: Local-only, non-destructive. No GPU server involved. Do not
  paste secrets. Captured WAV files may contain audio content; keep them local
  and do not attach raw audio here.

Commands (PowerShell, from the project root on Windows):

```powershell
# 1. Create/activate a virtual environment and install client + windows-audio deps.
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -e ".[client]"
pip install -e ".[windows-audio]"

# 2. Enumerate microphone and loopback devices.
python -m client.audio.wav_cli list

# 3. Capture ~5s from the default microphone (speak during capture).
python -m client.audio.wav_cli capture --source microphone --seconds 5 --out mic_test.wav

# 4. Capture ~5s of system loopback (play audio during capture).
#    Use a --device index from the loopback list above if the default is wrong.
python -m client.audio.wav_cli capture --source loopback --seconds 5 --out loopback_test.wav

# 5. (Optional) Run the Windows-only integration tests.
pip install -e ".[dev]"
pytest -m windows_audio
```

Expected success indicators:
- Step 2 prints at least one input device and at least one loopback device.
- Steps 3 and 4 print a non-zero byte count and `frames > 0`, and produce
  `mic_test.wav` / `loopback_test.wav`.
- The WAV files are mono, 16000 Hz, 16-bit and audibly contain the captured
  audio (microphone speech / played system audio).
- Step 5 (if run) reports the `windows_audio` tests passing.

Expected artifacts:
- `mic_test.wav`, `loopback_test.wav` (keep local; do not upload raw audio).

Rollback or cleanup:
- Delete the generated WAV files. No system changes are made.

Return to Claude (with secrets/sensitive paths redacted):
- Exact commands used.
- Full stdout/stderr of steps 2-4 (and step 5 if run).
- For each WAV: file size, and confirmation of format (mono / 16000 Hz / 16-bit)
  and whether audio is audible. Do not attach the raw audio itself.
- Any observed errors or missing devices.

## Rules

- Mỗi action có ID duy nhất.
- Chỉ người dùng thực hiện thao tác GPU server.
- Claude phải dừng khi action có trạng thái `WAITING_FOR_USER` và kết quả là dependency cho bước tiếp theo.
- Sau khi nhận output, Claude cập nhật action thành `PASSED`, `FAILED` hoặc `NEEDS_MORE_INFO`.
