# Implementation Status

## Current phase

Phase 01: Contracts and protocol.

## Verification state

- Local verification: LOCAL_VERIFIED (Phase 00, Phase 01)
- Windows audio verification: NOT_STARTED
- GPU ASR verification: NOT_STARTED
- GPU translation verification: NOT_STARTED
- Hardware end-to-end verification: NOT_STARTED

## Completed

- [x] Phase 00: Local project foundation and backup workflow
- [x] Phase 01: Contracts and protocol
- [ ] Phase 02: Windows audio capture
- [ ] Phase 03: WebSocket streaming
- [ ] Phase 04: VAD and utterance state machine
- [ ] Phase 05: Final Whisper ASR
- [ ] Phase 06: Partial Whisper ASR and stable prefix
- [ ] Phase 07: Qwen translation with vLLM
- [ ] Phase 08: Completeness and finalization orchestration
- [ ] Phase 09: PySide6 client UI
- [ ] Phase 10: Reliability, security and observability
- [ ] Phase 11: End-to-end tests and Windows packaging

## Latest local snapshot

`.local_backups/20260810T042859Z_phase-01.zip` (pre-Phase-01 snapshot; excludes
`.venv`, `.local_backups`, models, caches, logs, recordings and secrets;
`.env.example` retained). Manifest with per-file SHA-256 alongside the zip.
The Phase 00 snapshot (`20260810T042453Z_phase-00.zip`) is retained.

## Commands last run locally

```
python scripts/local_backup.py --label phase-01
ruff format --check .
ruff check .
mypy client server shared
pytest -q -m "not gpu and not windows_audio"
```

## Local test results

- ruff format --check: PASS (57 files formatted)
- ruff check: PASS (all checks passed)
- mypy client server shared: PASS (no issues in 13 source files)
- pytest (CPU, not gpu/not windows_audio): PASS (47 passed)
  - test_settings.py: 6 passed
  - test_health.py: 2 passed
  - test_logging_redaction.py: 6 passed
  - test_backup.py: 4 passed
  - test_protocol_messages.py: 10 passed
  - test_protocol_binary.py: 12 passed (incl. truncated/oversized/length-mismatch/
    misaligned/version boundary cases and a 500-iteration random fuzz)
  - test_protocol_sequence.py: 7 passed
- One non-blocking warning: Starlette TestClient httpx deprecation notice
  (from FastAPI test client, not project code).

## Phase 01 deliverables

- `shared/protocol/enums.py`: `EventType`, `Language`, `StreamSource`,
  `Encoding`, `FinalReason`, `TranslationStatus`, `ErrorCode`, `PROTOCOL_VERSION`.
- `shared/protocol/messages.py`: Pydantic v2 schemas for `session.start`,
  `audio.ack`, `transcription.partial`, `utterance.final`,
  `translation.updated`, `error`, plus `StreamConfig`/`LatencyInfo`. UTC
  timestamps serialize to ISO-8601 `...Z` with millisecond precision; extra
  fields forbidden; doc examples validated.
- `shared/protocol/binary.py`: 24-byte big-endian header codec
  (`>BBHQQI`), `encode_packet`/`decode_packet`/`validate_header`, `AudioFlags`,
  and `PacketValidationError`. Validates version, stream number, declared vs
  actual length, size limit and PCM S16LE 2-byte alignment.
- `shared/protocol/sequence.py`: `SequenceTracker` with duplicate detection,
  out-of-order buffering, last-contiguous ack and gap reporting.
- Serialization helpers are independent of FastAPI and PySide6.
- Live WebSocket networking intentionally deferred to Phase 03.

## Manual actions waiting for user

None. Phase 01 is pure CPU-side contract code; no GPU or Windows-hardware
verification required.

## User-provided hardware results

None.

## Known limitations

- `whisper_device` defaults to `cuda`; CPU-only local runs do not load ASR.
- GPU and Windows-audio dependency groups are declared but not installed or
  verified locally.
- Readiness endpoint checks only settings presence; dependency checks (Redis,
  ASR, translation) arrive in later phases.
- Protocol code defines contracts only; no transport/networking yet (Phase 03).

## Next action

Run `prompts/phases/02_WINDOWS_AUDIO.md` (Phase 02: Windows audio capture).
Create a local snapshot before starting.
