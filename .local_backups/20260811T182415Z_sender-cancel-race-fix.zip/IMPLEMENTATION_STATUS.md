# Implementation Status

## Current phase

Phase 06: Partial Whisper ASR and stable prefix.

## Verification state

- Local verification: LOCAL_VERIFIED (Phase 00, Phase 01, Phase 02, Phase 03, Phase 04, Phase 05,
  Phase 06). See "Local test results" for one pre-existing, unrelated local
  test failure discovered while running this phase's checks (not caused by
  Phase 06 and not fixed under this phase's scope; see "Known limitations").
- Windows audio verification: HARDWARE_VERIFIED (WINDOWS-AUDIO-001 PASSED 2026-08-10)
- GPU ASR verification: HARDWARE_VERIFIED for the `WhisperAsrModel` adapter
  itself (GPU-ASR-001 environment inspection PASSED 2026-08-10; GPU-ASR-002
  faster-whisper install INCONCLUSIVE 2026-08-11, superseded; GPU-ASR-003
  ctranslate2/CUDA visibility PASSED 2026-08-11; GPU-ASR-004 real model
  load/decode smoke test PASSED 2026-08-11; GPU-ASR-005 real-speech adapter
  test PASSED 2026-08-12, user confirmed both vi/ja transcripts roughly
  accurate). Still HARDWARE_PENDING for gateway/VAD-integrated end-to-end use
  and for scored accuracy/latency benchmarking — neither has been attempted.
- GPU translation verification: NOT_STARTED
- Hardware end-to-end verification: NOT_STARTED

## Completed

- [x] Phase 00: Local project foundation and backup workflow
- [x] Phase 01: Contracts and protocol
- [x] Phase 02: Windows audio capture
- [x] Phase 03: WebSocket streaming
- [x] Phase 04: VAD and utterance state machine
- [x] Phase 05: Final Whisper ASR
- [x] Phase 06: Partial Whisper ASR and stable prefix
- [ ] Phase 07: Qwen translation with vLLM
- [ ] Phase 08: Completeness and finalization orchestration
- [ ] Phase 09: PySide6 client UI
- [ ] Phase 10: Reliability, security and observability
- [ ] Phase 11: End-to-end tests and Windows packaging

## Latest local snapshot

`.local_backups/20260811T173029Z_phase-06.zip` (pre-Phase-06 snapshot; excludes
`.venv`, `.local_backups`, models, caches, logs, recordings and secrets;
`.env.example` retained). Manifest with per-file SHA-256 alongside the zip.
Prior Phase 00/01/02/03/04/05 snapshots are retained.

## Commands last run locally

```
python scripts/local_backup.py --label phase-06
ruff format .
ruff check .
mypy client server shared
pytest -q -m "not gpu and not windows_audio"
```

Note: this environment's `.venv` had only the base package installed (no
`dev` extra); `pip install -e ".[dev]"` was run first to make
`ruff`/`mypy`/`pytest` available before running the checks above.

## Local test results

- ruff format: PASS (1 file reformatted, 118 unchanged)
- ruff check: PASS (all checks passed)
- mypy client server shared: PASS (no issues in 52 source files)
- pytest (CPU, not gpu/not windows_audio): 186 passed, 1 failed, 2 deselected
  (187 collected)
  - Phase 06 partial-ASR suites (36 new):
    - test_asr_stable_prefix.py: 10 passed (first-hypothesis no-commit,
      two-hypothesis agreement for Vietnamese and Japanese (no spaces),
      punctuation-variation does not prematurely commit, a later contradicting
      hypothesis does not rewrite committed text, committed text never
      shrinks across a sequence, stable-boundary-ms segment mapping, window
      reset keeps committed text but restarts agreement, finalize)
    - test_asr_sliding_window.py: 9 passed (append/accumulate, advance
      no-ops on a non-positive boundary, advance keeps the overlap margin,
      advance clamps at zero when overlap exceeds the boundary, advance
      clamps to the actually-buffered length so it can never over-trim,
      advance is relative to the current window across repeated trims)
    - test_asr_partial_scheduler.py: 9 passed (interval validation, not due
      before the interval, due-and-reschedule, stop removes an utterance,
      independent streams scheduled by their own start time, simultaneous
      due utterances all returned so none is starved, a missed/late tick
      reschedules from "now" rather than the missed due time so it cannot
      burst catch-up decodes)
    - test_asr_partial.py: 10 passed (unknown/no-audio utterances return no
      event, first partial event published with correct revision/text/
      timing, duplicate stable+unstable text is suppressed, revision only
      increases on a real content change, `previous_text` conditioning uses
      the committed text, a decode superseded by a newer one or by the
      utterance being stopped mid-flight is discarded rather than applied)
  - `AsrConfig` gained `partial_beam_size` (mirrors `whisper_partial_beam_size`);
    test_asr_config.py extended with 1 new test (2 new assertions total).
  - All partial-ASR tests use `ScriptedAsrModel`; no weights are downloaded,
    no real Whisper/CUDA/asyncio-timer dependency.
  - 1 pre-existing failure, unrelated to Phase 06:
    `tests/test_transport_sender.py::test_run_reconnects_and_resends_pending`
    (Phase 03 client reconnect test) times out after 2s in this environment.
    Reproduces in isolation with only that file, with none of this phase's
    files present, so it is not caused by this phase's changes. Not fixed
    under this phase's scope (Phase 03 code, "do not proceed to another
    phase"); see "Known limitations".
  - (Prior 129 VAD/transport/protocol/audio tests otherwise unchanged.)
- windows_audio-marked tests remain deselected on this environment.
- One non-blocking warning: Starlette TestClient httpx deprecation notice
  (from FastAPI test client, not project code).

## Phase 03 deliverables

Server transport (`server/transport/`):
- `auth.py`: `Authenticator` interface, `AuthContext`, `AuthError`, and the
  functional dev `StaticTokenAuthenticator` (anonymous in non-production or a
  constant-time shared-token check). Production JWT validation slots in behind
  the same interface; no placeholder crypto shipped.
- `limits.py`: monotonic-time `TokenBucket` packet rate limiter.
- `jitter_buffer.py`: per-stream reorder buffer; holds out-of-order packets,
  releases contiguously, deduplicates, rejects stale packets, and force-advances
  past oversized gaps (bounded capacity, reported loss).
- `acks.py`: `AckBatcher` emitting one `audio.ack` per N packets or T ms.
- `session.py`: `StreamContext`, `Session`, `SessionManager` built from a
  validated `session.start` (unique ids, per-stream contexts, stream cap).
- `gateway.py`: FastAPI `/ws/stream` endpoint — handshake + validation, auth,
  independent binary ingest per stream, batched acks, payload/rate limits,
  keepalive/idle handling and typed `error` events. Never logs payloads/text.

Client transport (`client/transport/`):
- `backoff.py`: deterministic exponential `ReconnectBackoff` with optional
  injectable jitter.
- `outbound.py`: bounded `OutboundBuffer` (drop-oldest) of unacked frames for
  idempotent resend.
- `sender.py`: `AudioSender` with a `Transport` protocol (injectable),
  session handshake, per-stream sequence assignment, ack-driven buffer
  release, and a reconnect loop that resends unacked frames on each connect.
  `WebSocketClientTransport` (lazy `websockets`) provides the real socket.

Wiring/tooling:
- `server/app.py` now mounts the gateway with a dev authenticator and session
  manager.
- `shared/settings.py` + `.env.example`: transport, ack-batching, jitter,
  idle/heartbeat, rate-limit, auth-token and reconnect settings.
- mypy override treats `websockets` as an external untyped import.

## Phase 04 deliverables

VAD segmentation (`server/vad/`), pure synchronous CPU logic with no I/O,
FastAPI, Qt or CUDA coupling:
- `types.py`: audio constants (16 kHz S16LE, `BYTES_PER_MS`), the `VadState`
  enum (IDLE, SPEECH_STARTING, SPEAKING, POSSIBLE_END, FINALIZING), the frozen
  `VadConfig` (thresholds/durations/padding with validation and a
  `from_settings` mapping) and the frozen `Utterance` value object (id, source,
  timestamps, speech duration, final reason, audio buffer).
- `events.py`: `VadEventType` and frozen event records `SpeechStarted`,
  `SoftSilence`, `ResumedSpeech`, `UtteranceFinalized`, plus the `VadEvent`
  union.
- `interface.py`: `VadModel` runtime-checkable protocol (`probability`,
  `reset`) documented to run off the event loop.
- `fake.py`: deterministic `ScriptedVadModel` for tests (per-call probabilities,
  clamps to the last value when exhausted, `reset` rewinds).
- `silero.py`: `SileroVadModel` adapter with lazy `torch`/`silero_vad`
  initialization, 512-sample windowing and int16→float32 conversion; kept out
  of the CPU suite.
- `ring_buffer.py`: bounded `PreRollBuffer` (deque of recent frames) supporting
  pre-roll snapshots; disabled cleanly when capacity is below one frame.
- `state_machine.py`: `UtteranceSegmenter` — the per-stream IDLE/
  SPEECH_STARTING/SPEAKING/POSSIBLE_END machine. Confirms speech after
  `speech_start_ms`, prepends pre-roll audio, emits speech-start, soft-silence
  (once) and resumed-speech events, finalizes on hard silence or max utterance,
  trims trailing silence to `speech_pad_after_ms`, discards sub-`min_speech_ms`
  utterances (unless force-flushed), assigns incrementing utterance ids, and
  supports forced finalization via `flush(reason)`.

Tooling:
- mypy override extended to treat `silero_vad` and `torch` as external untyped
  imports.

## Manual actions waiting for user

### GPU-ASR-001 (PASSED 2026-08-10)

Read-only inspection of the ASR GPU host: NVIDIA H100 80GB HBM3 (0 MiB used),
driver 580.82.07, CUDA (driver) 13.0, nvcc 12.8, 128 CPUs, 1.5 TiB RAM (696 GiB
free), ample disk on both the container overlay and the persistent `/workspace`
PVC, Python 3.11.13. Host is a containerized/Kubernetes pod, not bare metal. No
errors observed. Full output is recorded in `USER_RESULTS.md`; the action entry
is now under "Completed actions" in `MANUAL_ACTIONS.md`.

### GPU-ASR-002 (INCONCLUSIVE 2026-08-11, superseded)

Installed `faster-whisper` 1.2.1 into a venv on the GPU host successfully
(real path confirmed by GPU-ASR-003 as
`/workspace/meetting-translator/.venv-asr`, not `/workspace/.venv-asr` as
first assumed). The action also asked for `import torch`, which failed with
`ModuleNotFoundError`. That check was a mistake in the action, not a real
signal: `faster-whisper` runs inference through CTranslate2, and the
project's `pyproject.toml` `gpu` extra pins only `faster-whisper>=1.0,<2`
with no PyTorch dependency, so a missing `torch` module proves nothing about
GPU readiness. Full result recorded in `USER_RESULTS.md`; action entry moved
to "Completed actions" (INCONCLUSIVE) in `MANUAL_ACTIONS.md`.

### GPU-ASR-003 (PASSED 2026-08-11)

Corrected diagnostic: `ctranslate2` 4.8.1 installed, `cuda_device_count()`
returned 1 (CTranslate2 sees the H100). Active interpreter and installed
packages confirmed inside the venv; `nvidia-smi` matched GPU-ASR-001.
`libcudart`/`libcublas`/`libcublasLt` resolved via `ldconfig`; `libcudnn`
did not appear in that listing. Per this action's own stated success
criteria (a missing `ldconfig` match only disqualifies if
`cuda_device_count` is 0), this is not treated as a failure, but it is an
open question carried into GPU-ASR-004: a real model load/decode is the
only way to confirm cuDNN (if needed by CTranslate2's ops) is actually
resolvable, since enumerating a CUDA device does not require loading a
model. Full result recorded in `USER_RESULTS.md`; action entry moved to
"Completed actions" in `MANUAL_ACTIONS.md`.

### GPU-ASR-004 (PASSED 2026-08-11)

First real GPU decode: downloaded `large-v3` weights (revision
`edaa852ec7e145841d8ffdb056a99866b5f0a478`, ~2.88 GiB) and ran one
`model.transcribe()` call against a locally-synthesized sine tone. Model
load (3.66s) and decode (0.29s) both completed with no CUDA/cuDNN/cuBLAS
error — resolving the open question from GPU-ASR-003 about `libcudnn` not
appearing in `ldconfig`. Still not an accuracy test (synthetic tone, no real
speech). Full result recorded in `USER_RESULTS.md`; action entry moved to
"Completed actions" in `MANUAL_ACTIONS.md`.

### GPU-ASR-005 (PASSED 2026-08-12)

First real-speech, real-code-path check: ran the project's own
`WhisperAsrModel` adapter (`server/asr/whisper.py`), built with the
project's documented `AsrConfig` defaults, against two real-speech WAV
samples (`vi_sample.wav`, 28s; `ja_sample.wav`, 20s). No exception for
either language; `segments > 0` for both (7 and 8); both outputs are
fluent, coherent, well-formed text in their respective language (Vietnamese
company-profile passage; Japanese textbook sentence-pattern examples) — see
`USER_RESULTS.md` for full text. User confirmed the ground-truth criterion:
"yes, the printed text is a roughly accurate rendering of what i said," for
both clips. This is the first hardware confirmation that the project's own
ASR adapter code (not just bare faster-whisper/ctranslate2) produces
plausible real transcripts in both target languages. Broader scored
accuracy/latency benchmarking and wiring `FinalTranscriber` into the live
gateway/VAD path remain separate, not-yet-started work.

No manual action is currently pending.

## Phase 05 deliverables

Final ASR (`server/asr/`), framework-independent domain logic plus a lazy GPU
adapter:
- `types.py`: audio constants, the frozen `AsrConfig` (model/device/
  compute_type/final_beam_size/temperature/condition_on_previous_text with
  validation and a `from_settings` mapping to the `whisper_*` baseline),
  `AsrRequest` (audio + decode options + optional conditioning prompt, with a
  `duration_ms` helper) and the frozen result models `TranscriptionSegment` /
  `TranscriptionResult`.
- `errors.py`: `AsrErrorKind` and the typed `AsrError` hierarchy
  (`ModelUnavailableError`, `AsrTimeoutError`, `AsrOutOfMemoryError`,
  `AsrDecodeError`) with `retryable` flags, an `error_code` mapping to
  `ErrorCode.ASR_FAILED`, and `classify_backend_error` to normalize backend
  exceptions (OOM / model-missing / decode) without importing GPU libraries.
- `interface.py`: `AsrModel` runtime-checkable protocol documented to run off
  the event loop.
- `fake.py`: deterministic `ScriptedAsrModel` (scripted results/errors, request
  recording) for CPU tests.
- `whisper.py`: `WhisperAsrModel` faster-whisper adapter with lazy `WhisperModel`
  load, int16->float32 conversion, per-language decode with beam/temperature/
  conditioning, and backend-error mapping. Excluded from the CPU suite.
- `worker.py`: `FinalTranscriber` runs decoding in a dedicated single-worker
  executor (never blocks the event loop; final ASR prioritized/serialized),
  enforces `asr_final_timeout_ms` via `wait_for` (timeout -> `AsrTimeoutError`),
  performs final reconciliation over completed utterance audio, and `finalize()`
  builds the `utterance.final` event with the transcription and
  `translation=None` / `translation_status=pending`. `build_asr_error_event`
  maps a typed error to a protocol `error` event.

Configuration/tooling:
- `shared/settings.py` + `.env.example`: added `whisper_final_beam_size`,
  `whisper_partial_beam_size`, `whisper_temperature`,
  `whisper_condition_on_previous_text` and `asr_final_timeout_ms`.
- mypy override extended to treat `faster_whisper` as an external untyped import.

## Phase 06 deliverables

Streaming partial ASR (`server/asr/`), pure/testable domain logic plus a thin
async orchestrator, mirroring the layering already used for transport
(`AckBatcher`) and final ASR (`FinalTranscriber`) — no gateway/VAD wiring yet
(consistent with Phase 05's `FinalTranscriber`, which is also not yet wired
into the live ingest path):
- `stable_prefix.py`: `StablePrefixTracker`/`StablePrefixResult` — pure,
  Whisper-independent local-agreement text merging. Commits text only once it
  agrees, segment-for-segment, across two consecutive decodes of the same
  audio window (comparing whole Whisper segments, not characters or
  whitespace-split words, so it works uniformly for Japanese and Vietnamese
  and never truncates mid-token). Committed text is monotonic — a later
  contradicting hypothesis cannot rewrite it. `stable_boundary_ms` maps the
  committed prefix back to a window-relative audio timestamp for windowing;
  `reset_window` restarts the agreement baseline (without discarding
  committed text) after the audio window shifts; `finalize` commits full text.
- `sliding_window.py`: `SlidingAudioWindow` — pure, growing PCM buffer for one
  in-progress utterance. `advance` drops audio already confirmed stable,
  keeping a configurable `overlap_ms` safety margin before the boundary (so a
  word spanning the trim point is not cut acoustically) and clamps to what is
  actually buffered so a boundary from an inconsistent backend can never
  over-trim. Continuity for dropped audio comes from feeding committed text
  back as `AsrRequest.previous_text`, not from re-decoding it.
- `partial_scheduler.py`: `PartialDecodeScheduler` — pure, time-injected
  (matches `AckBatcher`'s style) per-utterance due-time tracking at a
  configurable interval (`whisper_partial_interval_ms`, default 500ms).
  Independent per-stream due times, all simultaneously-due utterances
  returned (no stream starved), and a missed/slow tick reschedules from "now"
  rather than the missed due time so a gap cannot cause a catch-up burst.
- `partial.py`: `PartialTranscriber` — composes the above with an `AsrModel`
  to produce `transcription.partial` events. Runs decoding off the event loop
  in a dedicated executor (like `FinalTranscriber`); per-utterance state
  (window, tracker, revision, last-published text, a decode "generation"
  counter). Protections: duplicate stable/unstable text is not republished;
  revision only increases and only on a real change; a decode result that
  completes after the utterance was stopped or after a newer decode
  superseded it is discarded rather than applied (checked via the generation
  counter and utterance presence, both re-checked after the `await`).
  `current_revision` is exposed for a future final-reconciliation caller to
  assign the final event a strictly higher revision than the last partial
  (not wired up in this phase — final ASR's own revision handling is
  untouched, per "final reconciliation remains authoritative").

Configuration:
- `types.py`: `AsrConfig` gained `partial_beam_size: int = 1` (validated >= 1)
  and `from_settings` now maps `whisper_partial_beam_size`. `final_beam_size`
  and `FinalTranscriber` are unchanged.

Not in this phase's scope (consistent with Phase 05 precedent and the phase
prompt's own scope): a live asyncio loop driving `PartialDecodeScheduler` on
a wall clock, and wiring `PartialTranscriber`/`FinalTranscriber` into the
gateway/VAD ingest path. See "Known limitations".

## User-provided hardware results

- WINDOWS-AUDIO-001 (PASSED, 2026-08-10): see `USER_RESULTS.md`. Unchanged by
  Phase 05.
- GPU-ASR-001 (PASSED, 2026-08-10): see `USER_RESULTS.md`. ASR GPU host
  confirmed capable (H100 80GB, CUDA 13.0, Python 3.11.13).
- GPU-ASR-002 (INCONCLUSIVE, 2026-08-11): see `USER_RESULTS.md`.
  `faster-whisper` 1.2.1 installed; the action's `torch` check was invalid
  (not a project dependency) and proved nothing about GPU readiness.
  Superseded by GPU-ASR-003.
- GPU-ASR-003 (PASSED, 2026-08-11): see `USER_RESULTS.md`. `ctranslate2`
  4.8.1 sees 1 CUDA device on the H100; real venv path confirmed as
  `/workspace/meetting-translator/.venv-asr`. `libcudnn` not seen via
  `ldconfig` — not disqualifying per this action's own criteria, but left as
  an open question for GPU-ASR-004's real model load.
- GPU-ASR-004 (PASSED, 2026-08-11): see `USER_RESULTS.md`. `large-v3`
  (revision `edaa852ec7e145841d8ffdb056a99866b5f0a478`) loaded (3.66s) and
  decoded a synthetic tone (0.29s) with no CUDA/cuDNN/cuBLAS error, resolving
  GPU-ASR-003's open cuDNN question.
- GPU-ASR-005 (PASSED, 2026-08-12): see `USER_RESULTS.md`. No exception,
  `segments > 0` for both languages, fluent well-formed vi/ja text; user
  confirmed both transcripts roughly accurate.

## Known limitations

- `whisper_device` defaults to `cuda`; CPU-only local runs do not load ASR.
- GPU dependency group: the host is confirmed capable (GPU-ASR-001 PASSED),
  `faster-whisper` 1.2.1 is installed on the GPU host venv (GPU-ASR-002),
  `ctranslate2` confirms the GPU is visible and enumerable (GPU-ASR-003
  PASSED), and a real `large-v3` model load + decode succeeded with no
  CUDA/cuDNN/cuBLAS error (GPU-ASR-004 PASSED), and GPU-ASR-005 confirmed the
  real adapter produces plausible transcripts on real vi/ja speech, per the
  user's own judgment (PASSED 2026-08-12). The ASR adapter itself is now
  hardware-verified end-to-end on a two-sample plausibility basis; scored
  accuracy/latency benchmarking across more samples has not been done.
- `WhisperAsrModel` is implemented, hardware-confirmed for model-load/decode
  (GPU-ASR-004), and hardware-confirmed for real-speech plausibility in both
  target languages (GPU-ASR-005, user-judged roughly accurate). It is still
  excluded from the CPU suite (needs the GPU/model weights). Scored accuracy
  and latency across a larger sample set remain unmeasured/future work.
- The `FinalTranscriber` is not yet wired into the gateway/VAD ingest path;
  connecting utterance finalization to real audio and emitting `utterance.final`
  over the socket is integrated in a later phase. Translation is not attached
  yet (events carry `translation=null` / status `pending`).
- The gateway validates, orders and acknowledges audio but does not yet forward
  released frames into the `UtteranceSegmenter`; wiring VAD into the ingest path
  (and running probabilities off the event loop) lands with the ASR phases.
- `PartialTranscriber`/`PartialDecodeScheduler` (Phase 06) are implemented and
  unit-tested with a scripted model, but not yet wired into the gateway/VAD
  ingest path or driven by a live asyncio loop — same status as
  `FinalTranscriber`. `transcription.partial` events are not yet actually
  published over a real socket. Not hardware-verified: `PartialTranscriber`
  uses the same `WhisperAsrModel`/`AsrModel` interface already
  hardware-verified for final decoding (GPU-ASR-004/005), but no GPU-side
  smoke test has exercised `partial_beam_size`/the partial code path
  specifically; that would be natural follow-up manual work if/when this
  phase's output is integrated, not required to close Phase 06's own scope
  (which is local domain logic per `prompts/phases/06_WHISPER_PARTIAL.md`).
- Pre-existing, unrelated to Phase 06:
  `tests/test_transport_sender.py::test_run_reconnects_and_resends_pending`
  (Phase 03) times out deterministically (2s) in this native-Windows
  PowerShell `.venv` environment; reproduces in isolation with none of this
  phase's files present. Not investigated or fixed here (Phase 03 code, out
  of this phase's scope, and "do not proceed to another phase"). Needs a
  dedicated, explicitly-scoped follow-up: earlier local runs recorded it
  passing (`tests\__pycache__` held `cpython-312` bytecode before this
  session's `cpython-311` venv was set up), so this may be a Windows-specific
  asyncio event-loop behavior difference from whatever environment last
  validated it, not a regression introduced by any phase's source changes.
- `SileroVadModel` is implemented but unverified: it is excluded from the CPU
  suite and requires `torch`/`silero_vad` weights, so real VAD accuracy is not
  yet hardware-verified. Segmentation logic is verified with scripted
  probabilities only.
- Only `StaticTokenAuthenticator` (development) is provided; a production JWT
  authenticator implementing the `Authenticator` interface is future work.
- `WebSocketClientTransport` requires the `websockets` package (client/server
  extras); it is imported lazily and covered by unit tests via a fake transport
  rather than a live socket.

## Next action

Phase 06 (Partial Whisper ASR and stable prefix) is implemented and
LOCAL_VERIFIED: `ruff format`/`ruff check`/`mypy` clean, and the CPU suite
(`pytest -q -m "not gpu and not windows_audio"`) is 186 passed / 1 failed /
2 deselected, where the 1 failure is the pre-existing, unrelated
`test_transport_sender.py::test_run_reconnects_and_resends_pending` issue
described under "Known limitations" (reproduced in isolation, not caused by
this phase, not fixed here per "do not proceed to another phase"). No manual
GPU/Windows action was required for this phase's own scope (pure domain
logic, per `prompts/phases/06_WHISPER_PARTIAL.md`); no `MANUAL_ACTIONS.md`
change was made.

Do not proceed to Phase 07 or any other phase automatically. Before further
work, the user should decide between: (a) starting Phase 07
(`prompts/phases/07_QWEN_TRANSLATION.md`, if present), (b) a dedicated,
separately-scoped investigation of the pre-existing `test_transport_sender.py`
failure, or (c) wiring `PartialTranscriber`/`FinalTranscriber` into the
gateway/VAD ingest path. Take a local snapshot first
(`python scripts/local_backup.py --label <name>`) before starting whichever
is chosen.
