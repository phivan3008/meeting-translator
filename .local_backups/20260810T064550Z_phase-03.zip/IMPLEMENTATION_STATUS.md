# Implementation Status

## Current phase

Phase 02: Windows audio capture.

## Verification state

- Local verification: LOCAL_VERIFIED (Phase 00, Phase 01, Phase 02)
- Windows audio verification: HARDWARE_VERIFIED (WINDOWS-AUDIO-001 PASSED 2026-08-10)
- GPU ASR verification: NOT_STARTED
- GPU translation verification: NOT_STARTED
- Hardware end-to-end verification: NOT_STARTED

## Completed

- [x] Phase 00: Local project foundation and backup workflow
- [x] Phase 01: Contracts and protocol
- [x] Phase 02: Windows audio capture
- [ ] Phase 03: WebSocket streaming
- [ ] Phase 04: VAD and utterance state machine
- [ ] Phase 05: Final Whisper ASR
- [ ] Phase 06: Partial Whisper ASR and stable prefix
- [ ] Phase 07: Qwen translation with vLLM
- [ ] Phase 08: Completeness and finalization orchestration
- [ ] Phase 09: PySide6 client UI
- [ ] Phase 10: Reliability, security and observability
- [ ] Phase 11: End-to-end tests and Windows packaging

## Latest local snapshot

`.local_backups/20260810T044039Z_phase-02.zip` (pre-Phase-02 snapshot; excludes
`.venv`, `.local_backups`, models, caches, logs, recordings and secrets;
`.env.example` retained). Manifest with per-file SHA-256 alongside the zip.
Prior Phase 00/01 snapshots are retained.

## Commands last run locally

```
python scripts/local_backup.py --label phase-02
.venv\Scripts\python.exe -m pip install -e ".[dev]"   # adds numpy
ruff format --check .
ruff check .
mypy client server shared
pytest -q -m "not gpu and not windows_audio"
pytest -q -m "windows_audio" --co   # confirm marker wiring (2 collected)
```

## Local test results

- ruff format --check: PASS (70 files formatted)
- ruff check: PASS (all checks passed)
- mypy client server shared: PASS (no issues in 22 source files)
- pytest (CPU, not gpu/not windows_audio): PASS (65 passed)
  - Phase 00/01 suites: 47 passed (unchanged)
  - test_audio_conversion.py: 8 passed
  - test_audio_queue.py: 4 passed
  - test_audio_capture.py: 6 passed
- windows_audio-marked tests: 2 collected and deselected on Linux/without
  hardware (test_windows_audio.py). Executed manually per WINDOWS-AUDIO-001.
- One non-blocking warning: Starlette TestClient httpx deprecation notice
  (from FastAPI test client, not project code).

## Phase 02 deliverables

- `client/audio/types.py`: `AudioFormat`, `DeviceInfo`, `RawChunk`,
  `AudioFrame`, `CaptureEvent`, `DropPolicy`, and 20 ms frame constants
  (`FRAME_SAMPLES=320`, `FRAME_BYTES=640`). Reuses `StreamSource`.
- `client/audio/queue.py`: `BoundedAudioQueue` with DROP_OLDEST/DROP_NEWEST
  policy and accepted/dropped/overflow counters (non-blocking `put`).
- `client/audio/conversion.py`: deterministic downmix-to-mono, linear-interp
  resample to 16 kHz, S16LE output, and `FrameAssembler` 20 ms packetization.
- `client/audio/interface.py`: `AudioBackend`/`BackendStream` Protocols and
  positional-only chunk/event callback Protocols.
- `client/audio/capture.py`: `CaptureContext` — callback does only
  timestamp+sequence+bounded enqueue; worker converts and packetizes. Exposes
  device-loss/reconfigure signals and per-stream counters.
- `client/audio/fake_backend.py`: deterministic Linux backend (sine/chunk
  emission, simulated device loss/reconfigure).
- `client/audio/windows_backend.py`: PyAudioWPatch adapter importing
  `pyaudiowpatch` lazily; independent mic/loopback streams; callback only
  timestamps and forwards bytes. No sounddevice; mic and loopback never mixed.
- `client/audio/wav_cli.py`: `list` / `capture` diagnostic CLI for manual
  Windows verification (writes normalized mono 16 kHz WAV).
- Tests: fake-backend deterministic tests on Linux; Windows integration tests
  marked `windows_audio`.
- Tooling: `numpy` added to the dev extra; mypy override skips numpy 2.x stubs
  (3.12-only syntax) and treats `pyaudiowpatch` as external.

## Manual actions waiting for user

None. WINDOWS-AUDIO-001 completed (PASSED, 2026-08-10).

## User-provided hardware results

- WINDOWS-AUDIO-001 (PASSED, 2026-08-10): device enumeration found 8 input and
  2 loopback devices; microphone capture wrote `mic_test.wav`
  (158720 bytes, 248 frames, dropped=0); loopback capture on device 17 wrote
  `loopback_test.wav` (159360 bytes, 249 frames, dropped=0). No errors. Frame
  counts match mono 16 kHz S16LE 20 ms framing. Details in `USER_RESULTS.md`.

## Known limitations

- `whisper_device` defaults to `cuda`; CPU-only local runs do not load ASR.
- GPU and Windows-audio dependency groups are declared; GPU not installed
  locally, Windows-audio not yet hardware-verified.
- Readiness endpoint checks only settings presence; dependency checks (Redis,
  ASR, translation) arrive in later phases.
- Protocol defines contracts only; live WebSocket networking arrives in Phase 03.
- Audio worker is exposed as a synchronous `process_available` drain; the
  threaded real-time loop wiring to transport is added in Phase 03.

## Next action

Windows-audio hardware verification is complete (WINDOWS-AUDIO-001 PASSED). The
next implementation phase is `prompts/phases/03_WEBSOCKET_STREAMING.md` (Phase
03: WebSocket streaming). Create a local snapshot before starting Phase 03.
