# Implementation Status

## Current phase

Phase 04: VAD and utterance state machine.

## Verification state

- Local verification: LOCAL_VERIFIED (Phase 00, Phase 01, Phase 02, Phase 03, Phase 04)
- Windows audio verification: HARDWARE_VERIFIED (WINDOWS-AUDIO-001 PASSED 2026-08-10)
- GPU ASR verification: NOT_STARTED
- GPU translation verification: NOT_STARTED
- Hardware end-to-end verification: NOT_STARTED

## Completed

- [x] Phase 00: Local project foundation and backup workflow
- [x] Phase 01: Contracts and protocol
- [x] Phase 02: Windows audio capture
- [x] Phase 03: WebSocket streaming
- [x] Phase 04: VAD and utterance state machine
- [ ] Phase 05: Final Whisper ASR
- [ ] Phase 06: Partial Whisper ASR and stable prefix
- [ ] Phase 07: Qwen translation with vLLM
- [ ] Phase 08: Completeness and finalization orchestration
- [ ] Phase 09: PySide6 client UI
- [ ] Phase 10: Reliability, security and observability
- [ ] Phase 11: End-to-end tests and Windows packaging

## Latest local snapshot

`.local_backups/20260810T071246Z_phase-04.zip` (pre-Phase-04 snapshot; excludes
`.venv`, `.local_backups`, models, caches, logs, recordings and secrets;
`.env.example` retained). Manifest with per-file SHA-256 alongside the zip.
Prior Phase 00/01/02/03 snapshots are retained.

## Commands last run locally

```
python scripts/local_backup.py --label phase-04
ruff format .
ruff check .
mypy client server shared
pytest -q -m "not gpu and not windows_audio"
```

## Local test results

- ruff format: PASS (2 files reformatted, 99 unchanged)
- ruff check: PASS (all checks passed)
- mypy client server shared: PASS (no issues in 41 source files)
- pytest (CPU, not gpu/not windows_audio): PASS (129 passed, 2 deselected)
  - Phase 04 VAD suites (19 new):
    - test_vad_config.py: 4 passed (from_settings mapping + validation guards)
    - test_vad_ring_buffer.py: 5 passed (pre-roll retention/clear/zero-capacity,
      scripted-model sequence/clamp/reset/validation)
    - test_vad_state_machine.py: 10 passed (confirm with pre-roll, hard-silence
      finalize + trailing-silence trim, resumed speech, soft-silence once,
      short-utterance discard, max-utterance finalize, false start, forced
      flush, flush-during-starting discard, zero-padding start, sequential ids)
- (Prior 110 transport/protocol/audio tests unchanged.)
  - test_transport_backoff.py: 4 passed
  - test_transport_outbound.py: 4 passed
  - test_transport_jitter_buffer.py: 6 passed
  - test_transport_acks.py: 5 passed
  - test_transport_auth.py: 5 passed
  - test_transport_limits.py: 4 passed
  - test_transport_session.py: 4 passed
  - test_transport_gateway.py: 8 passed (handshake, two-stream acks, duplicate,
    keepalive, and typed-error paths via Starlette WebSocket test client)
  - test_transport_sender.py: 5 passed (handshake/resend, ack drop, error
    callback, reconnect + idempotent resend)
- windows_audio-marked tests remain deselected on this environment.
- One non-blocking warning: Starlette TestClient httpx deprecation notice
  (from FastAPI test client, not project code).

## Phase 03 deliverables

Server transport (`server/transport/`):
- `auth.py`: `Authenticator` interface, `AuthContext`, `AuthError`, and the
  functional dev `StaticTokenAuthenticator` (anonymous in non-production or a
  constant-time shared-token check). Production JWT validation slots in behind
  the same interface; no placeholder crypto shipped.
- `limits.py`: monotonic-time `TokenBucket` packet rate limiter.
- `jitter_buffer.py`: per-stream reorder buffer; holds out-of-order packets,
  releases contiguously, deduplicates, rejects stale packets, and force-advances
  past oversized gaps (bounded capacity, reported loss).
- `acks.py`: `AckBatcher` emitting one `audio.ack` per N packets or T ms.
- `session.py`: `StreamContext`, `Session`, `SessionManager` built from a
  validated `session.start` (unique ids, per-stream contexts, stream cap).
- `gateway.py`: FastAPI `/ws/stream` endpoint — handshake + validation, auth,
  independent binary ingest per stream, batched acks, payload/rate limits,
  keepalive/idle handling and typed `error` events. Never logs payloads/text.

Client transport (`client/transport/`):
- `backoff.py`: deterministic exponential `ReconnectBackoff` with optional
  injectable jitter.
- `outbound.py`: bounded `OutboundBuffer` (drop-oldest) of unacked frames for
  idempotent resend.
- `sender.py`: `AudioSender` with a `Transport` protocol (injectable),
  session handshake, per-stream sequence assignment, ack-driven buffer
  release, and a reconnect loop that resends unacked frames on each connect.
  `WebSocketClientTransport` (lazy `websockets`) provides the real socket.

Wiring/tooling:
- `server/app.py` now mounts the gateway with a dev authenticator and session
  manager.
- `shared/settings.py` + `.env.example`: transport, ack-batching, jitter,
  idle/heartbeat, rate-limit, auth-token and reconnect settings.
- mypy override treats `websockets` as an external untyped import.

## Phase 04 deliverables

VAD segmentation (`server/vad/`), pure synchronous CPU logic with no I/O,
FastAPI, Qt or CUDA coupling:
- `types.py`: audio constants (16 kHz S16LE, `BYTES_PER_MS`), the `VadState`
  enum (IDLE, SPEECH_STARTING, SPEAKING, POSSIBLE_END, FINALIZING), the frozen
  `VadConfig` (thresholds/durations/padding with validation and a
  `from_settings` mapping) and the frozen `Utterance` value object (id, source,
  timestamps, speech duration, final reason, audio buffer).
- `events.py`: `VadEventType` and frozen event records `SpeechStarted`,
  `SoftSilence`, `ResumedSpeech`, `UtteranceFinalized`, plus the `VadEvent`
  union.
- `interface.py`: `VadModel` runtime-checkable protocol (`probability`,
  `reset`) documented to run off the event loop.
- `fake.py`: deterministic `ScriptedVadModel` for tests (per-call probabilities,
  clamps to the last value when exhausted, `reset` rewinds).
- `silero.py`: `SileroVadModel` adapter with lazy `torch`/`silero_vad`
  initialization, 512-sample windowing and int16→float32 conversion; kept out
  of the CPU suite.
- `ring_buffer.py`: bounded `PreRollBuffer` (deque of recent frames) supporting
  pre-roll snapshots; disabled cleanly when capacity is below one frame.
- `state_machine.py`: `UtteranceSegmenter` — the per-stream IDLE/
  SPEECH_STARTING/SPEAKING/POSSIBLE_END machine. Confirms speech after
  `speech_start_ms`, prepends pre-roll audio, emits speech-start, soft-silence
  (once) and resumed-speech events, finalizes on hard silence or max utterance,
  trims trailing silence to `speech_pad_after_ms`, discards sub-`min_speech_ms`
  utterances (unless force-flushed), assigns incrementing utterance ids, and
  supports forced finalization via `flush(reason)`.

Tooling:
- mypy override extended to treat `silero_vad` and `torch` as external untyped
  imports.

## Manual actions waiting for user

None. Phase 04 is pure CPU segmentation logic verified with deterministic
probability frames. The real Silero adapter (`SileroVadModel`) is implemented
with lazy `torch`/`silero_vad` initialization but is intentionally excluded from
the CPU suite; loading real VAD weights is a GPU/manual step for a later phase.
No GPU or Windows-hardware verification is required to close Phase 04.

## User-provided hardware results

- WINDOWS-AUDIO-001 (PASSED, 2026-08-10): see `USER_RESULTS.md`. Unchanged by
  Phase 04.

## Known limitations

- `whisper_device` defaults to `cuda`; CPU-only local runs do not load ASR.
- GPU dependency group is declared but not installed or verified locally.
- Readiness endpoint checks only settings presence; dependency checks (Redis,
  ASR, translation) arrive in later phases.
- The gateway validates, orders and acknowledges audio but does not yet forward
  released frames into the `UtteranceSegmenter`; wiring VAD into the ingest path
  (and running probabilities off the event loop) lands with the ASR phases.
- `SileroVadModel` is implemented but unverified: it is excluded from the CPU
  suite and requires `torch`/`silero_vad` weights, so real VAD accuracy is not
  yet hardware-verified. Segmentation logic is verified with scripted
  probabilities only.
- Only `StaticTokenAuthenticator` (development) is provided; a production JWT
  authenticator implementing the `Authenticator` interface is future work.
- `WebSocketClientTransport` requires the `websockets` package (client/server
  extras); it is imported lazily and covered by unit tests via a fake transport
  rather than a live socket.

## Next action

Proceed to `prompts/phases/05_WHISPER_FINAL.md` (Phase 05: Final Whisper ASR).
Create a local snapshot before starting Phase 05
(`python scripts/local_backup.py --label phase-05`).
