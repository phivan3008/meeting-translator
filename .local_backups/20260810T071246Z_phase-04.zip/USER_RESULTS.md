# User-Provided Verification Results

File này lưu tóm tắt kết quả kiểm thử thủ công do người dùng cung cấp. Không lưu secret hoặc nội dung cuộc họp nhạy cảm.

## Results

### WINDOWS-AUDIO-001

- Date: 2026-08-10
- Environment: Windows, PowerShell, project root (virtualized audio devices:
  VMware / Teradici virtual microphone and speakers).
- Command summary:
  - `python -m client.audio.wav_cli list`
  - `python -m client.audio.wav_cli capture --source microphone --seconds 5 --out mic_test.wav`
  - `python -m client.audio.wav_cli capture --source loopback --seconds 5 --out loopback_test.wav --device 17`
- Exit status: 0 for all commands.
- Result: PASSED
- Relevant output summary:
  - Enumeration: 8 input devices and 2 loopback devices detected. Loopback
    devices were [16] Teradici and [17] VMware (DevTap).
  - Microphone capture: `mic_test.wav` = 158720 bytes, 248 frames, dropped=0.
  - Loopback capture (device 17): `loopback_test.wav` = 159360 bytes,
    249 frames, dropped=0.
  - Frame math consistent with mono 16 kHz S16LE 20 ms frames (640 bytes/frame;
    248 x 640 = 158720, 249 x 640 = 159360), i.e. ~4.96-4.98 s of audio.
  - No errors observed.
- Redacted raw output file, if any: none (raw WAV audio not attached, kept local).
- Follow-up: Windows audio marked HARDWARE_VERIFIED. Independent mic/loopback
  capture confirmed on real (virtualized) Windows devices.

## Result template

```markdown
### Action ID

- Date:
- Environment:
- Command summary:
- Exit status:
- Result: PASSED | FAILED | INCONCLUSIVE
- Relevant output summary:
- Redacted raw output file, if any:
- Follow-up:
```
