"""Environment-based application settings with validation.

Settings are loaded from process environment variables and an optional local
``.env`` file. No secret values are hard-coded here. Defaults mirror
``.env.example`` and the baseline configuration documented under ``docs/``.
"""

from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

AppEnv = Literal["development", "staging", "production"]
LogLevel = Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]


class Settings(BaseSettings):
    """Validated application settings.

    All fields are populated from environment variables. Field names map to
    upper-case environment keys (case-insensitive).
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # --- Application ---------------------------------------------------------
    app_env: AppEnv = "development"
    log_level: LogLevel = "INFO"

    # --- Server transport ----------------------------------------------------
    server_host: str = "0.0.0.0"
    server_port: int = Field(default=8080, ge=1, le=65535)
    ws_max_packet_bytes: int = Field(default=65536, ge=64, le=8 * 1024 * 1024)
    ws_max_streams_per_session: int = Field(default=8, ge=1, le=255)
    ws_ack_every_packets: int = Field(default=32, ge=1)
    ws_ack_every_ms: int = Field(default=200, ge=1)
    ws_jitter_buffer_capacity: int = Field(default=64, ge=1)
    ws_idle_timeout_ms: int = Field(default=15000, ge=1)
    ws_heartbeat_interval_ms: int = Field(default=5000, ge=1)
    ws_rate_limit_packets_per_sec: float = Field(default=200.0, gt=0.0)
    ws_rate_limit_burst: int = Field(default=400, ge=1)

    # --- Client reconnect/backoff -------------------------------------------
    reconnect_backoff_initial_ms: int = Field(default=250, ge=1)
    reconnect_backoff_max_ms: int = Field(default=10000, ge=1)
    reconnect_backoff_multiplier: float = Field(default=2.0, ge=1.0)
    client_outbound_buffer_frames: int = Field(default=512, ge=1)

    # --- Authentication ------------------------------------------------------
    jwt_issuer: str = "meeting-translator"
    jwt_audience: str = "meeting-translator-client"
    jwt_public_key_path: str = ""
    # Development shared token. Empty string allows anonymous access in the
    # development environment only; production must supply a JWT authenticator.
    auth_dev_token: str = ""

    # --- Infrastructure ------------------------------------------------------
    redis_url: str = "redis://localhost:6379/0"

    # --- VAD baseline --------------------------------------------------------
    vad_threshold: float = Field(default=0.50, ge=0.0, le=1.0)
    vad_speech_start_ms: int = Field(default=160, ge=0)
    vad_min_speech_ms: int = Field(default=250, ge=0)
    vad_soft_silence_ms: int = Field(default=450, ge=0)
    vad_hard_silence_ms: int = Field(default=900, ge=0)
    vad_speech_pad_before_ms: int = Field(default=200, ge=0)
    vad_speech_pad_after_ms: int = Field(default=250, ge=0)
    vad_max_utterance_ms: int = Field(default=15000, ge=1)

    # --- ASR baseline --------------------------------------------------------
    whisper_model: str = "large-v3"
    whisper_device: str = "cuda"
    whisper_compute_type: str = "float16"
    whisper_partial_interval_ms: int = Field(default=500, ge=1)
    whisper_audio_overlap_ms: int = Field(default=1500, ge=0)

    # --- Translation baseline ------------------------------------------------
    vllm_base_url: str = "http://localhost:8000/v1"
    vllm_api_key: str = "EMPTY"
    vllm_model: str = "qwen3.6-27b-translate"
    translation_timeout_ms: int = Field(default=3000, ge=1)
    translation_max_concurrency: int = Field(default=8, ge=1)
    translation_max_input_tokens: int = Field(default=768, ge=1)
    translation_max_output_tokens: int = Field(default=256, ge=1)
    completeness_enabled: bool = True
    completeness_timeout_ms: int = Field(default=250, ge=1)
    completeness_skip_queue_depth: int = Field(default=4, ge=0)

    # --- Privacy toggles -----------------------------------------------------
    store_raw_audio: bool = False
    log_transcript_content: bool = False
    log_translation_content: bool = False

    @field_validator("vad_hard_silence_ms")
    @classmethod
    def _hard_silence_after_soft(cls, value: int, info: object) -> int:
        # Pydantic v2 passes a ValidationInfo with .data holding prior fields.
        data = getattr(info, "data", {})
        soft = data.get("vad_soft_silence_ms")
        if soft is not None and value < soft:
            raise ValueError(
                "vad_hard_silence_ms must be greater than or equal to vad_soft_silence_ms"
            )
        return value

    @property
    def is_production(self) -> bool:
        """Return True when running in the production environment."""
        return self.app_env == "production"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return a cached, validated settings instance."""
    return Settings()
