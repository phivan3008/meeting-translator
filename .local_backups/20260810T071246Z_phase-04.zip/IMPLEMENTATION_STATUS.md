# Implementation Status

## Current phase

Phase 03: WebSocket streaming.

## Verification state

- Local verification: LOCAL_VERIFIED (Phase 00, Phase 01, Phase 02, Phase 03)
- Windows audio verification: HARDWARE_VERIFIED (WINDOWS-AUDIO-001 PASSED 2026-08-10)
- GPU ASR verification: NOT_STARTED
- GPU translation verification: NOT_STARTED
- Hardware end-to-end verification: NOT_STARTED

## Completed

- [x] Phase 00: Local project foundation and backup workflow
- [x] Phase 01: Contracts and protocol
- [x] Phase 02: Windows audio capture
- [x] Phase 03: WebSocket streaming
- [ ] Phase 04: VAD and utterance state machine
- [ ] Phase 05: Final Whisper ASR
- [ ] Phase 06: Partial Whisper ASR and stable prefix
- [ ] Phase 07: Qwen translation with vLLM
- [ ] Phase 08: Completeness and finalization orchestration
- [ ] Phase 09: PySide6 client UI
- [ ] Phase 10: Reliability, security and observability
- [ ] Phase 11: End-to-end tests and Windows packaging

## Latest local snapshot

`.local_backups/20260810T064550Z_phase-03.zip` (pre-Phase-03 snapshot; excludes
`.venv`, `.local_backups`, models, caches, logs, recordings and secrets;
`.env.example` retained). Manifest with per-file SHA-256 alongside the zip.
Prior Phase 00/01/02 snapshots are retained.

## Commands last run locally

```
python scripts/local_backup.py --label phase-03
ruff format .
ruff format --check .
ruff check .
mypy client server shared
pytest -q -m "not gpu and not windows_audio"
```

## Local test results

- ruff format --check: PASS (90 files formatted)
- ruff check: PASS (all checks passed)
- mypy client server shared: PASS (no issues in 33 source files)
- pytest (CPU, not gpu/not windows_audio): PASS (110 passed, 2 deselected)
  - Phase 00/01/02 suites: 65 passed (unchanged)
  - test_transport_backoff.py: 4 passed
  - test_transport_outbound.py: 4 passed
  - test_transport_jitter_buffer.py: 6 passed
  - test_transport_acks.py: 5 passed
  - test_transport_auth.py: 5 passed
  - test_transport_limits.py: 4 passed
  - test_transport_session.py: 4 passed
  - test_transport_gateway.py: 8 passed (handshake, two-stream acks, duplicate,
    keepalive, and typed-error paths via Starlette WebSocket test client)
  - test_transport_sender.py: 5 passed (handshake/resend, ack drop, error
    callback, reconnect + idempotent resend)
- windows_audio-marked tests remain deselected on this environment.
- One non-blocking warning: Starlette TestClient httpx deprecation notice
  (from FastAPI test client, not project code).

## Phase 03 deliverables

Server transport (`server/transport/`):
- `auth.py`: `Authenticator` interface, `AuthContext`, `AuthError`, and the
  functional dev `StaticTokenAuthenticator` (anonymous in non-production or a
  constant-time shared-token check). Production JWT validation slots in behind
  the same interface; no placeholder crypto shipped.
- `limits.py`: monotonic-time `TokenBucket` packet rate limiter.
- `jitter_buffer.py`: per-stream reorder buffer; holds out-of-order packets,
  releases contiguously, deduplicates, rejects stale packets, and force-advances
  past oversized gaps (bounded capacity, reported loss).
- `acks.py`: `AckBatcher` emitting one `audio.ack` per N packets or T ms.
- `session.py`: `StreamContext`, `Session`, `SessionManager` built from a
  validated `session.start` (unique ids, per-stream contexts, stream cap).
- `gateway.py`: FastAPI `/ws/stream` endpoint — handshake + validation, auth,
  independent binary ingest per stream, batched acks, payload/rate limits,
  keepalive/idle handling and typed `error` events. Never logs payloads/text.

Client transport (`client/transport/`):
- `backoff.py`: deterministic exponential `ReconnectBackoff` with optional
  injectable jitter.
- `outbound.py`: bounded `OutboundBuffer` (drop-oldest) of unacked frames for
  idempotent resend.
- `sender.py`: `AudioSender` with a `Transport` protocol (injectable),
  session handshake, per-stream sequence assignment, ack-driven buffer
  release, and a reconnect loop that resends unacked frames on each connect.
  `WebSocketClientTransport` (lazy `websockets`) provides the real socket.

Wiring/tooling:
- `server/app.py` now mounts the gateway with a dev authenticator and session
  manager.
- `shared/settings.py` + `.env.example`: transport, ack-batching, jitter,
  idle/heartbeat, rate-limit, auth-token and reconnect settings.
- mypy override treats `websockets` as an external untyped import.

## Manual actions waiting for user

None. Phase 03 is CPU-side transport logic verified with in-process WebSocket
tests; no GPU or Windows-hardware verification is required for this phase.

## User-provided hardware results

- WINDOWS-AUDIO-001 (PASSED, 2026-08-10): see `USER_RESULTS.md`. Unchanged by
  Phase 03.

## Known limitations

- `whisper_device` defaults to `cuda`; CPU-only local runs do not load ASR.
- GPU dependency group is declared but not installed or verified locally.
- Readiness endpoint checks only settings presence; dependency checks (Redis,
  ASR, translation) arrive in later phases.
- The gateway validates, orders and acknowledges audio but does not yet forward
  released frames to VAD/ASR (added in Phase 04+).
- Only `StaticTokenAuthenticator` (development) is provided; a production JWT
  authenticator implementing the `Authenticator` interface is future work.
- `WebSocketClientTransport` requires the `websockets` package (client/server
  extras); it is imported lazily and covered by unit tests via a fake transport
  rather than a live socket.

## Next action

Proceed to `prompts/phases/04_VAD_UTTERANCE.md` (Phase 04: VAD and utterance
state machine). Create a local snapshot before starting Phase 04.
