# Manual Actions

Claude ghi các thao tác mà người dùng cần thực hiện tại đây.

## Pending actions

Chưa có.

## Completed actions

### Action ID: WINDOWS-AUDIO-001

- Status: PASSED (2026-08-10)
- Result summary: Device enumeration listed 8 input devices and 2 loopback
  devices. Microphone capture wrote `mic_test.wav` (158720 bytes, 248 frames,
  dropped=0). Loopback capture on device 17 wrote `loopback_test.wav`
  (159360 bytes, 249 frames, dropped=0). No errors observed.
- Purpose: Verify Windows audio device enumeration and short microphone/loopback
  WAV capture using the PyAudioWPatch backend. Confirms real devices are found
  and captured audio normalizes to mono 16 kHz PCM S16LE.
- Run on: Windows 10/11 machine with a working microphone and audio output.
- Prerequisites:
  - This project directory copied to the Windows machine.
  - Python 3.11+ available.
  - A meeting/audio app or media playing during the loopback capture so the
    loopback WAV is not silent.
- Safety notes: Local-only, non-destructive. No GPU server involved. Do not
  paste secrets. Captured WAV files may contain audio content; keep them local
  and do not attach raw audio here.

Commands (PowerShell, from the project root on Windows):

```powershell
# 1. Create/activate a virtual environment and install client + windows-audio deps.
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -e ".[client]"
pip install -e ".[windows-audio]"

# 2. Enumerate microphone and loopback devices.
python -m client.audio.wav_cli list

# 3. Capture ~5s from the default microphone (speak during capture).
python -m client.audio.wav_cli capture --source microphone --seconds 5 --out mic_test.wav

# 4. Capture ~5s of system loopback (play audio during capture).
#    Use a --device index from the loopback list above if the default is wrong.
python -m client.audio.wav_cli capture --source loopback --seconds 5 --out loopback_test.wav

# 5. (Optional) Run the Windows-only integration tests.
pip install -e ".[dev]"
pytest -m windows_audio
```

Expected success indicators:
- Step 2 prints at least one input device and at least one loopback device.
- Steps 3 and 4 print a non-zero byte count and `frames > 0`, and produce
  `mic_test.wav` / `loopback_test.wav`.
- The WAV files are mono, 16000 Hz, 16-bit and audibly contain the captured
  audio (microphone speech / played system audio).
- Step 5 (if run) reports the `windows_audio` tests passing.

Expected artifacts:
- `mic_test.wav`, `loopback_test.wav` (keep local; do not upload raw audio).

Rollback or cleanup:
- Delete the generated WAV files. No system changes are made.

Return to Claude (with secrets/sensitive paths redacted):
- Exact commands used.
- Full stdout/stderr of steps 2-4 (and step 5 if run).
- For each WAV: file size, and confirmation of format (mono / 16000 Hz / 16-bit)
  and whether audio is audible. Do not attach the raw audio itself.
- Any observed errors or missing devices.

## Rules

- Mỗi action có ID duy nhất.
- Chỉ người dùng thực hiện thao tác GPU server.
- Claude phải dừng khi action có trạng thái `WAITING_FOR_USER` và kết quả là dependency cho bước tiếp theo.
- Sau khi nhận output, Claude cập nhật action thành `PASSED`, `FAILED` hoặc `NEEDS_MORE_INFO`.
