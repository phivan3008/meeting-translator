# User-Provided Verification Results

File này lưu tóm tắt kết quả kiểm thử thủ công do người dùng cung cấp. Không lưu secret hoặc nội dung cuộc họp nhạy cảm.

## Results

### GPU-ASR-001

- Date: 2026-08-10
- Environment: GPU server (containerized/Kubernetes pod; PVC-backed
  `/workspace`, overlay root filesystem, nvidia-fabricmanager present).
- Command summary:
  - `nvidia-smi`
  - `nvcc --version`
  - `free -h ; nproc`
  - `df -h .`
  - `python3 --version`
- Exit status: no errors observed for any command.
- Result: PASSED
- Relevant output summary:
  - GPU: 1x NVIDIA H100 80GB HBM3, 0 MiB / 81559 MiB used, driver 580.82.07,
    CUDA (driver) 13.0, no other processes running on the GPU.
  - `nvcc`: CUDA 12.8 toolkit (release 12.8, V12.8.93) present.
  - Host: 128 logical CPUs, 1.5 TiB total RAM, 696 GiB free, no swap.
  - Disk: container overlay 24T total / 18T avail; persistent `/workspace` PVC
    mount 300G total / 156G avail — both comfortably sufficient for the
    faster-whisper large-v3 weights (~3 GB).
  - Python: 3.11.13 (meets the 3.11+ requirement).
  - No errors, missing tools or insufficient-resource warnings reported.
- Redacted raw output file, if any: none (full command output pasted inline,
  no secrets or hostnames present).
- Follow-up: GPU ASR host confirmed capable of hosting faster-whisper
  large-v3. Marked PASSED in `MANUAL_ACTIONS.md`. Next step was GPU-ASR-002
  (install the faster-whisper package only into a persistent venv).

### GPU-ASR-002

- Date: 2026-08-11
- Environment: GPU server, `/workspace/meetting-translator/.venv-asr` virtual
  environment (confirmed exact path via GPU-ASR-003's `which python` output;
  earlier actions assumed `/workspace/.venv-asr`).
- Command summary:
  - `pip install "faster-whisper>=1.0,<2"`
  - `python -c "import faster_whisper; print(...)"`
  - `python -c "import torch; print(...)"`
- Exit status: install succeeded; the `torch` import command failed.
- Result: INCONCLUSIVE (the action itself was flawed, not the environment)
- Relevant output summary:
  - `faster-whisper` installed at version 1.2.1.
  - `torch` import raised `ModuleNotFoundError: No module named 'torch'`.
- Redacted raw output file, if any: none.
- Follow-up: The `torch` check in GPU-ASR-002 was incorrect — `faster-whisper`
  executes inference through CTranslate2, not PyTorch, and the project's
  `pyproject.toml` `gpu` extra pins only `faster-whisper>=1.0,<2` with no
  PyTorch requirement. Missing `torch` is expected and not a failure signal.
  GPU-ASR-002 is marked INCONCLUSIVE/superseded in `MANUAL_ACTIONS.md`.
  GPU-ASR-003 checks GPU visibility through `ctranslate2` directly instead.

### GPU-ASR-003

- Date: 2026-08-11
- Environment: GPU server, `/workspace/meetting-translator/.venv-asr`.
- Command summary:
  - `python -c "import ctranslate2; print(...__version__)"`
  - `python -c "import ctranslate2; print(...get_cuda_device_count())"`
  - `which python`, `python --version`, `pip --version`, `pip list`
  - `nvidia-smi`
  - `python -c "import ctranslate2, os; print(os.path.dirname(...))"`
  - `ldconfig -p | grep -i -E "cudnn|cublas|cudart"`
- Exit status: no errors observed for any command.
- Result: PASSED (for what it tests — see follow-up)
- Relevant output summary:
  - `ctranslate2` 4.8.1; `cuda_device_count()` = 1.
  - Active interpreter: `/workspace/meetting-translator/.venv-asr/bin/python`,
    Python 3.11.13, pip 26.2.1. Installed set includes `faster-whisper`
    1.2.1, `ctranslate2` 4.8.1, `numpy` 2.4.6, `onnxruntime` 1.28.0,
    `huggingface_hub` 1.27.0, `tokenizers` 0.23.1, `av` 18.0.0, and their
    transitive deps — no `torch` and no `nvidia-cudnn-cu12`/similar package.
  - `nvidia-smi`: same H100 80GB as GPU-ASR-001, 0 MiB used, driver 580.82.07,
    CUDA 13.0, no processes.
  - `ldconfig` grep matched `libcudart.so(.12)`, `libcublas.so(.12)` and
    `libcublasLt.so(.12)` under `/usr/local/cuda/targets/x86_64-linux/lib/`.
    No `libcudnn*` entry appeared in the grep output.
- Redacted raw output file, if any: none.
- Follow-up: By this action's own stated success criteria, this passes —
  `cuda_device_count` is 1 (not 0), so the missing `cudnn` match in
  `ldconfig` is not treated as disqualifying. This confirms CTranslate2 can
  see and enumerate the GPU, and confirms the real venv path is
  `/workspace/meetting-translator/.venv-asr` (corrected from the
  `/workspace/.venv-asr` assumed in GPU-ASR-002/003's prepared commands).
  However, enumerating a device is not the same as a model successfully
  loading and decoding — cuDNN could still be missing (or simply not visible
  to `ldconfig`, e.g. bundled inside the `ctranslate2` wheel) and only
  surface as an error when a real forward pass runs. GPU ASR verification
  therefore remains HARDWARE_PENDING. GPU-ASR-004 runs an actual model load
  and one decode call to resolve this open question.

### GPU-ASR-004

- Date: 2026-08-11
- Environment: GPU server, `/workspace/meetting-translator/.venv-asr`.
- Command summary:
  - `python /tmp/asr_smoke_test.py` (loads `large-v3` on cuda/float16,
    synthesizes a 3s 440 Hz tone, runs one `transcribe()` call)
  - `python /tmp/model_info.py` (records the cached model revision via
    `huggingface_hub.scan_cache_dir()`)
- Exit status: no errors observed for either command.
- Result: PASSED
- Relevant output summary:
  - `model_load_seconds=3.66`, `decode_seconds=0.29`.
  - `detected_language=ja probability=1.000`, `segment_count=1` (not
    meaningful — input was a pure tone, no real speech).
  - `OK: model loaded and decode call completed without error`.
  - Model revision: `Systran/faster-whisper-large-v3` @
    `edaa852ec7e145841d8ffdb056a99866b5f0a478`, `size_on_disk=3090835702`
    bytes (~2.88 GiB).
- Redacted raw output file, if any: none.
- Follow-up: This is a clean pass by the action's own success criteria — a
  real `large-v3` model load and a real GPU decode both completed with no
  CUDA/cuDNN/cuBLAS exception. This resolves the open question from
  GPU-ASR-003 (missing `libcudnn` in `ldconfig`): whatever the actual
  dependency resolution is (e.g. bundled inside the `ctranslate2` wheel), it
  works in practice on this host. GPU ASR verification remains
  HARDWARE_PENDING overall (this test used synthetic audio, not real
  speech, so transcription plausibility is still unverified).
  GPU-ASR-005 (WAITING_FOR_USER) runs the project's actual `WhisperAsrModel`
  adapter against two short real-speech samples (vi, ja) to get a first
  plausibility signal.

### GPU-ASR-005

- Date: 2026-08-11
- Environment: GPU server, `/workspace/meetting-translator/.venv-asr`.
- Command summary:
  - `PYTHONPATH=/workspace/meetting-translator python /tmp/asr_real_speech_test.py`
    against real `vi_sample.wav` (~28s) and `ja_sample.wav` (~20s) recordings.
- Exit status: no errors observed.
- Result: PASSED (2026-08-12: user confirmed "yes, the printed text is a
  roughly accurate rendering of what i said" for both clips)
- Relevant output summary:
  - `vi` (`vi_sample.wav`): `duration_ms=28000`, `segments=7`. Text is fluent,
    coherent Vietnamese describing a company profile (a biotech/agriculture
    seed company founded in Đà Lạt in 1989, expansion into hybrid seed
    business in 1994).
  - `ja` (`ja_sample.wav`): `duration_ms=20000`, `segments=8`. Text is fluent,
    coherent Japanese in a textbook sentence-pattern style (交番, 案内書, 駅の
    トイレ example sentences).
- Redacted raw output file, if any: none (transcript text itself is the
  content; no secrets present, but see follow-up on sensitivity note below).
- Follow-up: Both outputs meet the action's objective success indicators —
  no exception for either language, `segments > 0` for both, and the text is
  linguistically well-formed in each target language — and the user has now
  confirmed the ground-truth criterion (roughly accurate for both clips).
  GPU-ASR-005 is PASSED and closed. This is the first hardware confirmation
  that the project's own `WhisperAsrModel` adapter, not just the bare
  faster-whisper/ctranslate2 libraries, produces plausible real transcripts
  in both target languages. It remains a two-sample plausibility check, not
  a scored accuracy/latency benchmark, and `FinalTranscriber` is still not
  wired into the live gateway/VAD ingest path — both are separate, later
  work.

### WINDOWS-AUDIO-001

- Date: 2026-08-10
- Environment: Windows, PowerShell, project root (virtualized audio devices:
  VMware / Teradici virtual microphone and speakers).
- Command summary:
  - `python -m client.audio.wav_cli list`
  - `python -m client.audio.wav_cli capture --source microphone --seconds 5 --out mic_test.wav`
  - `python -m client.audio.wav_cli capture --source loopback --seconds 5 --out loopback_test.wav --device 17`
- Exit status: 0 for all commands.
- Result: PASSED
- Relevant output summary:
  - Enumeration: 8 input devices and 2 loopback devices detected. Loopback
    devices were [16] Teradici and [17] VMware (DevTap).
  - Microphone capture: `mic_test.wav` = 158720 bytes, 248 frames, dropped=0.
  - Loopback capture (device 17): `loopback_test.wav` = 159360 bytes,
    249 frames, dropped=0.
  - Frame math consistent with mono 16 kHz S16LE 20 ms frames (640 bytes/frame;
    248 x 640 = 158720, 249 x 640 = 159360), i.e. ~4.96-4.98 s of audio.
  - No errors observed.
- Redacted raw output file, if any: none (raw WAV audio not attached, kept local).
- Follow-up: Windows audio marked HARDWARE_VERIFIED. Independent mic/loopback
  capture confirmed on real (virtualized) Windows devices.

## Result template

```markdown
### Action ID

- Date:
- Environment:
- Command summary:
- Exit status:
- Result: PASSED | FAILED | INCONCLUSIVE
- Relevant output summary:
- Redacted raw output file, if any:
- Follow-up:
```
