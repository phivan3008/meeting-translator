# Manual Actions

Claude ghi các thao tác mà người dùng cần thực hiện tại đây.

## Pending actions

(none)

## Completed actions

### Action ID: GPU-ASR-005

- Status: PASSED (2026-08-12)
- Result summary: Ran against real `vi_sample.wav` (28s) and `ja_sample.wav`
  (20s). No exception for either language; `segments > 0` for both (7 and
  8); output was fluent, coherent text in each language. User confirmed:
  "yes, the printed text is a roughly accurate rendering of what i said" —
  satisfying the action's ground-truth plausibility criterion for both
  clips. GPU ASR is now hardware-verified for the ASR adapter itself
  (real speech, real project code path, both target languages).
- Purpose: First real-speech, real-code-path check. Exercises the project's
  own `WhisperAsrModel` adapter (`server/asr/whisper.py`) — not the bare
  `faster_whisper` library — against short genuine speech samples in both
  target languages (`vi`, `ja`), using the project's documented `AsrConfig`
  defaults from `.env.example` (`large-v3`, `cuda`, `float16`,
  `final_beam_size=3`, `temperature=0.0`, `condition_on_previous_text=True`).
  This is a plausibility check ("is the transcribed text roughly what was
  said"), not a scored accuracy benchmark — that is separate, later work.
- Run on: GPU ASR server, inside the existing venv at
  `/workspace/meetting-translator/.venv-asr`, from the project root
  `/workspace/meetting-translator` (so `server`/`shared` import correctly).
- Prerequisites:
  - GPU-ASR-004 PASSED (confirmed below): `large-v3` loads and decodes on
    this GPU with no CUDA/cuDNN/cuBLAS error.
  - Two short (~5-10s) WAV recordings of clear, real speech: one Vietnamese,
    one Japanese, each mono / 16-bit / 16000 Hz. The easiest way to get a
    correctly-formatted file is the already-verified capture tool from
    WINDOWS-AUDIO-001, run on your Windows client while actually speaking a
    short sentence:
    `python -m client.audio.wav_cli capture --source microphone --seconds 8 --out vi_sample.wav`
    (repeat in Japanese for `ja_sample.wav`). Any other mono/16-bit/16000 Hz
    WAV of clear speech works too.
  - Those two WAV files copied onto the GPU host into
    `/workspace/meetting-translator/` as `vi_sample.wav` and `ja_sample.wav`
    (transfer method is up to you / your normal way of copying files onto
    this pod — not prescribed here).
- Safety notes: Reads two local WAV files and runs two inference calls
  through the already-installed venv. Does not modify the venv, drivers,
  containers, services, firewall or permissions, and downloads nothing new.
  The recorded speech is a throwaway test utterance, not real meeting
  content — please say something innocuous (e.g. count or read a sentence
  aloud) since the transcribed text will be pasted back into this chat, and
  avoid recording anything sensitive.

Commands (run on the GPU ASR host, with the venv active, from the project root):

```bash
source /workspace/meetting-translator/.venv-asr/bin/activate
cd /workspace/meetting-translator

# 1. Write a script that uses the project's real ASR adapter and config,
#    not bare faster_whisper.
cat > /tmp/asr_real_speech_test.py << 'EOF'
import wave
from server.asr.types import AsrConfig, AsrRequest
from server.asr.whisper import WhisperAsrModel
from shared.protocol.enums import Language


def load_pcm(path: str) -> bytes:
    with wave.open(path, "rb") as wf:
        if wf.getnchannels() != 1 or wf.getsampwidth() != 2 or wf.getframerate() != 16000:
            raise ValueError(
                f"{path}: expected mono/16-bit/16000Hz, got "
                f"channels={wf.getnchannels()} sampwidth={wf.getsampwidth()} "
                f"framerate={wf.getframerate()}"
            )
        return wf.readframes(wf.getnframes())


config = AsrConfig(
    model="large-v3",
    device="cuda",
    compute_type="float16",
    final_beam_size=3,
    temperature=0.0,
    condition_on_previous_text=True,
)
model = WhisperAsrModel(config)

for language, filename in [(Language.VIETNAMESE, "vi_sample.wav"), (Language.JAPANESE, "ja_sample.wav")]:
    audio = load_pcm(filename)
    request = AsrRequest(
        audio=audio,
        language=language,
        beam_size=config.final_beam_size,
        temperature=config.temperature,
        condition_on_previous_text=config.condition_on_previous_text,
    )
    result = model.transcribe(request)
    print(f"--- {language.value} ({filename}) ---")
    print(f"duration_ms={result.duration_ms}")
    print(f"segments={len(result.segments)}")
    print(f"text={result.text!r}")
EOF

# 2. Run it, keeping stderr visible for any error.
PYTHONPATH=/workspace/meetting-translator python /tmp/asr_real_speech_test.py
```

Expected success indicators:
- No exception/traceback for either language.
- `segments` > 0 for both.
- The printed `text` for `vi_sample.wav` is plausible, readable Vietnamese
  (with diacritics) roughly matching what was actually said; the printed
  `text` for `ja_sample.wav` is plausible, readable Japanese (kana/kanji)
  roughly matching what was actually said. You are the ground truth judge —
  this is a rough sanity check, not automated scoring.

Expected artifacts:
- None permanent. `/tmp/asr_real_speech_test.py` is temporary.

Rollback or cleanup:
- `rm /tmp/asr_real_speech_test.py`. Delete the WAV fixture files if desired
  (`vi_sample.wav`, `ja_sample.wav`).

Return to Claude (with secrets/sensitive paths redacted):
- Exact commands used and their exit status.
- Full stdout for both languages (the printed `text` fields), plus your own
  judgment of whether each is a roughly correct/plausible transcription of
  what you actually said.
- Any exception/traceback.

Received output: No exception for either language. `vi_sample.wav`:
`duration_ms=28000 segments=7`, fluent coherent Vietnamese (company profile
passage). `ja_sample.wav`: `duration_ms=20000 segments=8`, fluent coherent
Japanese (textbook sentence-pattern examples). User confirmed (2026-08-12):
"yes, the printed text is a roughly accurate rendering of what i said."
Full text recorded in `USER_RESULTS.md`.

Note: This was a plausibility check on two short clips, not a scored
accuracy benchmark. Broader accuracy/latency benchmarking across more
samples, and wiring `FinalTranscriber` into the live gateway/VAD path, are
separate, later work.

### Action ID: GPU-ASR-004

- Status: PASSED (2026-08-11)
- Result summary: `large-v3` loaded in 3.66s and decoded a synthetic 3s tone
  in 0.29s with no exception — real model weights, real GPU compute, no
  CUDA/cuDNN/cuBLAS load error. This resolves the open question left by
  GPU-ASR-003 (missing `libcudnn` in `ldconfig`): whatever the dependency
  resolution path, it works end-to-end on this host. Detected language/
  probability and segment count on the tone are not meaningful (no real
  speech in the input) and were expected to be arbitrary. Model revision
  recorded: `Systran/faster-whisper-large-v3` @
  `edaa852ec7e145841d8ffdb056a99866b5f0a478`, 3090835702 bytes (~2.88 GiB) on
  disk.
- Purpose: First real GPU decode (model load + one inference call) to prove
  the actual codepath works, not just CUDA device enumeration.
- Run on: GPU ASR server, `/workspace/meetting-translator/.venv-asr`.
- Note: See GPU-ASR-005 for the first real-speech, real-adapter-code test.

### Action ID: GPU-ASR-003

- Status: PASSED (2026-08-11)
- Result summary: `ctranslate2` 4.8.1 installed and `cuda_device_count()`
  returned 1 — CTranslate2 (the library `faster-whisper` actually delegates
  GPU execution to) successfully sees the H100. Active Python/pip confirmed
  inside `/workspace/meetting-translator/.venv-asr` (note: the real venv path
  has an extra path segment — `meetting-translator`, not `/workspace`
  directly — earlier actions' assumed path is corrected in GPU-ASR-004).
  `faster-whisper` 1.2.1 and `ctranslate2` 4.8.1 both present in `pip list`.
  `nvidia-smi` shows the same idle H100 as GPU-ASR-001. `libcudart`/
  `libcublas`/`libcublasLt` resolved via `ldconfig`; no `libcudnn` entry
  appeared in that listing, but per this action's own stated success
  criteria a missing `ldconfig` match is only disqualifying when
  `cuda_device_count` is 0, which it was not — so this is not treated as a
  failure here. It is flagged as an open risk for GPU-ASR-004 (first real
  model load/decode) to either confirm is harmless (e.g. cuDNN bundled
  inside the `ctranslate2` wheel rather than resolved via system
  `ldconfig`) or surface as a load-time error.
- Purpose: Re-check GPU visibility through the library faster-whisper
  actually uses (`ctranslate2`), after GPU-ASR-002's flawed `torch` check.
- Run on: GPU ASR server, `/workspace/meetting-translator/.venv-asr`.
- Note: See GPU-ASR-004 for the first real model-load/decode test that
  resolves the open cuDNN-visibility question.

### Action ID: GPU-ASR-002

- Status: INCONCLUSIVE (2026-08-11)
- Result summary: `faster-whisper` 1.2.1 installed successfully. The prepared
  diagnostic additionally tried `import torch`, which failed with
  `ModuleNotFoundError` — but this was a flaw in the action as written, not a
  real failure signal: `faster-whisper` executes inference through
  CTranslate2, and the project's `pyproject.toml` `gpu` extra pins only
  `faster-whisper>=1.0,<2` with no PyTorch requirement. GPU visibility for the
  library `faster-whisper` actually uses was not checked by this action.
  Superseded by GPU-ASR-003, which checks `ctranslate2` directly.
- Purpose: Install only the faster-whisper GPU inference stack (not the full
  `gpu` extra, since translation may run on a separate GPU per
  `docs/ARCHITECTURE.md`) into a persistent virtual environment on the ASR GPU
  host, and confirm CUDA is visible to the installed PyTorch build. Installs
  packages only; downloads no model weights and runs no inference.
- Run on: GPU ASR server (same host as GPU-ASR-001: H100 80GB, driver
  580.82.07, CUDA 13.0, Python 3.11.13, containerized/Kubernetes pod with a
  persistent `/workspace` PVC mount).
- Prerequisites:
  - GPU-ASR-001 PASSED (confirmed below).
  - Project source copied to the GPU host under `/workspace` (or another path
    on the persistent PVC, not the ephemeral container overlay, so the venv
    survives a pod restart).
  - Outbound network access to PyPI (or an internal mirror) from the host.
- Safety notes: Installs Python packages into a new, isolated virtual
  environment only. Does not touch system Python, drivers, CUDA toolkit,
  containers, services, firewall or permissions. Does not download model
  weights. Do not paste secrets, tokens or full hostnames; redact as needed.

Commands (run on the GPU ASR host, from the project root under `/workspace`):

```bash
# 1. Create a persistent virtual environment on the PVC-backed path.
python3 -m venv /workspace/.venv-asr
source /workspace/.venv-asr/bin/activate

# 2. Upgrade packaging tools.
python -m pip install --upgrade pip

# 3. Install only the ASR inference dependency (pinned per pyproject.toml's
#    `gpu` extra: faster-whisper>=1.0,<2).
pip install "faster-whisper>=1.0,<2"

# 4. Confirm the installed stack imports.
python -c "import faster_whisper; print('faster_whisper', faster_whisper.__version__)"
```

Expected artifacts:
- `/workspace/.venv-asr/` virtual environment (persistent on the PVC). No
  model weights are downloaded by this action.

Rollback or cleanup:
- `rm -rf /workspace/.venv-asr` removes the environment; no other system
  state is changed.

Note: See GPU-ASR-003 for the corrected GPU-visibility diagnostic.

### Action ID: GPU-ASR-001

- Status: PASSED (2026-08-10)
- Result summary: NVIDIA H100 80GB HBM3, 0 MiB used / 81559 MiB total, driver
  580.82.07, CUDA (driver) 13.0, nvcc 12.8 (CUDA 12.8 toolkit). Host: 128
  logical CPUs, 1.5 TiB RAM (696 GiB free). Disk: container overlay 24T
  (18T avail), persistent `/workspace` PVC mount 300G (156G avail). Python
  3.11.13. Host is a containerized/Kubernetes pod (nvidia-fabricmanager
  socket, PVC-backed `/workspace`, overlay root filesystem) rather than bare
  metal — noted for later steps so installs/venvs target the persistent PVC
  path, not the ephemeral overlay. No errors observed.
- Purpose: Inspect the user-managed ASR GPU environment (read-only) to confirm
  it can host faster-whisper large-v3 before any model install or inference is
  prepared. This action installs nothing and runs no inference.
- Run on: GPU ASR server (the host that will run faster-whisper).
- Prerequisites:
  - A shell on the ASR GPU host.
  - `nvidia-smi` available (NVIDIA driver installed).
  - Python 3.11+ available (for the version check only).
- Safety notes: Read-only inspection. Does not install packages, download
  weights, change drivers, containers, services, firewall or permissions. Do
  not paste secrets, tokens or full hostnames; redact as needed.

Commands (run on the GPU ASR host):

```bash
# 1. GPU model, VRAM, driver and CUDA runtime version.
nvidia-smi

# 2. CUDA toolkit compiler version, if present (optional).
nvcc --version 2>/dev/null || echo "nvcc not on PATH (optional)"

# 3. Host CPU/RAM summary.
#    Linux:
free -h ; nproc
#    (Windows host alternative: systeminfo | findstr /C:"Total Physical Memory")

# 4. Free disk space where model weights will live (large-v3 ~ 3 GB).
df -h .

# 5. Python version available for the ASR service.
python3 --version 2>/dev/null || python --version
```

Expected success indicators:
- Step 1 prints at least one NVIDIA GPU with its total memory, driver version
  and the CUDA version supported by the driver.
- Step 3 shows the available system RAM and CPU count.
- Step 4 shows sufficient free disk (several GB) for model weights and cache.
- Step 5 reports Python 3.11 or newer.

Expected artifacts:
- None. Read-only; no files are created.

Rollback or cleanup:
- None required; no changes are made.

Return to Claude (with secrets/sensitive paths redacted):
- Exact commands used and their exit status.
- Full stdout/stderr of steps 1 and 3-5 (step 2 optional), with any tokens,
  private hostnames or personal paths redacted.
- The `nvidia-smi` GPU model, total VRAM, driver version and CUDA version.
- Any observed error, missing tool or insufficient resource.

Note: This is inspection only. Model installation and inference are separate,
later action IDs (e.g. GPU-ASR-002+) and must not begin until this action's
output is returned and analyzed.

### Action ID: WINDOWS-AUDIO-001

- Status: PASSED (2026-08-10)
- Result summary: Device enumeration listed 8 input devices and 2 loopback
  devices. Microphone capture wrote `mic_test.wav` (158720 bytes, 248 frames,
  dropped=0). Loopback capture on device 17 wrote `loopback_test.wav`
  (159360 bytes, 249 frames, dropped=0). No errors observed.
- Purpose: Verify Windows audio device enumeration and short microphone/loopback
  WAV capture using the PyAudioWPatch backend. Confirms real devices are found
  and captured audio normalizes to mono 16 kHz PCM S16LE.
- Run on: Windows 10/11 machine with a working microphone and audio output.
- Prerequisites:
  - This project directory copied to the Windows machine.
  - Python 3.11+ available.
  - A meeting/audio app or media playing during the loopback capture so the
    loopback WAV is not silent.
- Safety notes: Local-only, non-destructive. No GPU server involved. Do not
  paste secrets. Captured WAV files may contain audio content; keep them local
  and do not attach raw audio here.

Commands (PowerShell, from the project root on Windows):

```powershell
# 1. Create/activate a virtual environment and install client + windows-audio deps.
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -e ".[client]"
pip install -e ".[windows-audio]"

# 2. Enumerate microphone and loopback devices.
python -m client.audio.wav_cli list

# 3. Capture ~5s from the default microphone (speak during capture).
python -m client.audio.wav_cli capture --source microphone --seconds 5 --out mic_test.wav

# 4. Capture ~5s of system loopback (play audio during capture).
#    Use a --device index from the loopback list above if the default is wrong.
python -m client.audio.wav_cli capture --source loopback --seconds 5 --out loopback_test.wav

# 5. (Optional) Run the Windows-only integration tests.
pip install -e ".[dev]"
pytest -m windows_audio
```

Expected success indicators:
- Step 2 prints at least one input device and at least one loopback device.
- Steps 3 and 4 print a non-zero byte count and `frames > 0`, and produce
  `mic_test.wav` / `loopback_test.wav`.
- The WAV files are mono, 16000 Hz, 16-bit and audibly contain the captured
  audio (microphone speech / played system audio).
- Step 5 (if run) reports the `windows_audio` tests passing.

Expected artifacts:
- `mic_test.wav`, `loopback_test.wav` (keep local; do not upload raw audio).

Rollback or cleanup:
- Delete the generated WAV files. No system changes are made.

Return to Claude (with secrets/sensitive paths redacted):
- Exact commands used.
- Full stdout/stderr of steps 2-4 (and step 5 if run).
- For each WAV: file size, and confirmation of format (mono / 16000 Hz / 16-bit)
  and whether audio is audible. Do not attach the raw audio itself.
- Any observed errors or missing devices.

## Rules

- Mỗi action có ID duy nhất.
- Chỉ người dùng thực hiện thao tác GPU server.
- Claude phải dừng khi action có trạng thái `WAITING_FOR_USER` và kết quả là dependency cho bước tiếp theo.
- Sau khi nhận output, Claude cập nhật action thành `PASSED`, `FAILED` hoặc `NEEDS_MORE_INFO`.
