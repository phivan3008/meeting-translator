"""Tests for the client audio sender: handshake, resend, acks and reconnect.

A fake in-memory transport drives the sender's reconnect and idempotent-resend
behavior without any real socket.
"""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime

import pytest

from client.transport.backoff import ReconnectBackoff
from client.transport.sender import AudioSender, TransportClosed
from shared.protocol.enums import ErrorCode, Language, StreamSource
from shared.protocol.messages import (
    AudioAck,
    ErrorEvent,
    SessionStart,
    StreamConfig,
)


def _session_start() -> SessionStart:
    return SessionStart(
        session_id="sess-1",
        client_id="client-1",
        timestamp=datetime.now(UTC),
        streams=[
            StreamConfig(
                stream_number=1,
                stream_id="mic-01",
                source=StreamSource.MICROPHONE,
                source_language=Language.VIETNAMESE,
                target_language=Language.JAPANESE,
            ),
        ],
    )


class FakeTransport:
    """In-memory transport whose ``recv`` immediately signals a closed link."""

    def __init__(
        self,
        *,
        stop_event: asyncio.Event | None = None,
        set_stop_on_connect: bool = False,
    ) -> None:
        self.sent_text: list[str] = []
        self.sent_bytes: list[bytes] = []
        self.connected = False
        self.closed = False
        self._stop_event = stop_event
        self._set_stop_on_connect = set_stop_on_connect

    async def connect(self) -> None:
        self.connected = True
        if self._set_stop_on_connect and self._stop_event is not None:
            self._stop_event.set()

    async def send_text(self, data: str, /) -> None:
        self.sent_text.append(data)

    async def send_bytes(self, data: bytes, /) -> None:
        self.sent_bytes.append(data)

    async def recv(self) -> str | bytes:
        raise TransportClosed("closed")

    async def close(self) -> None:
        self.closed = True


def _sender(
    transport_factory,  # type: ignore[no-untyped-def]
    *,
    on_error=None,  # type: ignore[no-untyped-def]
) -> AudioSender:
    return AudioSender(
        session_start=_session_start(),
        transport_factory=transport_factory,
        backoff=ReconnectBackoff(initial_ms=1, max_ms=5),
        buffer_capacity=8,
        on_error=on_error,
    )


async def test_open_sends_handshake_and_resends_pending() -> None:
    sender = _sender(FakeTransport)
    sender.send_audio(stream_number=1, pcm=b"\x00\x00", client_timestamp_ms=1)
    sender.send_audio(stream_number=1, pcm=b"\x00\x00", client_timestamp_ms=2)

    transport = FakeTransport()
    await sender._open(transport)

    assert len(transport.sent_text) == 1
    assert "session.start" in transport.sent_text[0]
    assert len(transport.sent_bytes) == 2  # both pending frames resent


def test_ack_message_drops_buffered_frames() -> None:
    sender = _sender(FakeTransport)
    sender.send_audio(stream_number=1, pcm=b"\x00\x00", client_timestamp_ms=1)  # seq 0
    sender.send_audio(stream_number=1, pcm=b"\x00\x00", client_timestamp_ms=2)  # seq 1
    ack = AudioAck(
        session_id="sess-1",
        stream_id="mic-01",
        last_contiguous_sequence=0,
        timestamp=datetime.now(UTC),
    )
    sender._handle_message(ack.model_dump_json())
    assert len(sender.buffer_for(1)) == 1  # only seq 1 remains


def test_error_message_invokes_callback() -> None:
    received: list[ErrorEvent] = []
    sender = _sender(FakeTransport, on_error=received.append)
    error = ErrorEvent(
        session_id="sess-1",
        code=ErrorCode.OVERLOADED,
        message="slow down",
        retryable=True,
        timestamp=datetime.now(UTC),
    )
    sender._handle_message(error.model_dump_json())
    assert len(received) == 1
    assert received[0].code == ErrorCode.OVERLOADED


def test_send_audio_unknown_stream_raises() -> None:
    sender = _sender(FakeTransport)
    with pytest.raises(KeyError):
        sender.send_audio(stream_number=99, pcm=b"\x00\x00", client_timestamp_ms=1)


async def test_run_reconnects_and_resends_pending() -> None:
    stop = asyncio.Event()
    created: list[FakeTransport] = []

    def factory() -> FakeTransport:
        transport = FakeTransport(
            stop_event=stop,
            set_stop_on_connect=(len(created) == 1),
        )
        created.append(transport)
        return transport

    sender = _sender(factory)
    sender.send_audio(stream_number=1, pcm=b"\x00\x00", client_timestamp_ms=1)
    sender.send_audio(stream_number=1, pcm=b"\x00\x00", client_timestamp_ms=2)

    await asyncio.wait_for(sender.run(stop), timeout=2.0)

    assert len(created) == 2
    for transport in created:
        assert len(transport.sent_text) == 1  # handshake on each connection
        assert len(transport.sent_bytes) >= 2  # pending frames resent (idempotent)
        assert transport.closed is True
