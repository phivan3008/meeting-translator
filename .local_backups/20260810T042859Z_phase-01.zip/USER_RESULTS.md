# User-Provided Verification Results

File này lưu tóm tắt kết quả kiểm thử thủ công do người dùng cung cấp. Không lưu secret hoặc nội dung cuộc họp nhạy cảm.

## Results

Chưa có.

## Result template

```markdown
### Action ID

- Date:
- Environment:
- Command summary:
- Exit status:
- Result: PASSED | FAILED | INCONCLUSIVE
- Relevant output summary:
- Redacted raw output file, if any:
- Follow-up:
```
