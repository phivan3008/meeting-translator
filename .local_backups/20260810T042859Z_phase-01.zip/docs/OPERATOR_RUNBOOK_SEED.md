# Operator Runbook Seed

Claude must expand this file during implementation.

## Expected deployment

- Application server and Redis run as containers.
- faster-whisper runs on an assigned ASR GPU.
- vLLM runs `Qwen3.6-27B-FP8` on a separate translation GPU.
- A reverse proxy terminates TLS and forwards WebSocket traffic.

## Required runbook sections

- Prerequisites and GPU compatibility.
- Model download and checksum/version recording.
- vLLM launch and health verification.
- Application start and readiness verification.
- Windows client installation.
- Metrics and alert interpretation.
- Queue pressure response.
- Whisper or vLLM OOM response.
- Client reconnect and device-change troubleshooting.
- Safe shutdown.
- Privacy-preserving diagnostics.
- Backup and restore for non-content configuration only.
