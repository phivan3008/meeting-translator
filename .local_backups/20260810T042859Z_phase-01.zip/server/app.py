"""FastAPI application with liveness and readiness endpoints.

Liveness indicates the process is running. Readiness indicates the service is
prepared to accept work. In Phase 00 readiness reflects only that settings
loaded successfully; later phases extend it with model and dependency checks.
"""

from __future__ import annotations

from typing import Any

from fastapi import FastAPI, Response, status

from shared.logging import configure_logging
from shared.settings import Settings, get_settings


def create_app(settings: Settings | None = None) -> FastAPI:
    """Create and configure the FastAPI application."""
    resolved = settings or get_settings()
    configure_logging(resolved.log_level)

    app = FastAPI(title="Meeting Translator Server", version="0.0.0")
    app.state.settings = resolved

    @app.get("/health/live")
    def live() -> dict[str, Any]:
        """Liveness probe: the process is up."""
        return {"status": "alive", "app_env": resolved.app_env}

    @app.get("/health/ready")
    def ready(response: Response) -> dict[str, Any]:
        """Readiness probe.

        Phase 00 baseline: ready when settings are present. Dependency checks
        (Redis, ASR, translation) are added in later phases.
        """
        checks = {"settings": resolved is not None}
        is_ready = all(checks.values())
        if not is_ready:
            response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
        return {"status": "ready" if is_ready else "not_ready", "checks": checks}

    return app


app = create_app()
