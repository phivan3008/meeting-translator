"""Minimal PySide6 bootstrap for the Windows client.

PySide6 is imported lazily inside :func:`run` so that this module can be
imported (for metadata or tooling) without Qt installed. The CPU test suite
does not import this module. It is exercised manually on Windows.

Run with:

    python -m client.ui.bootstrap
"""

from __future__ import annotations

import sys


def run() -> int:
    """Launch a minimal placeholder window and return the Qt exit code.

    The real caption UI is implemented in Phase 09. This bootstrap only proves
    the Qt entry point is wired and isolated from CPU test imports.
    """
    from PySide6.QtWidgets import QApplication, QLabel  # noqa: PLC0415

    app = QApplication(sys.argv)
    label = QLabel("Meeting Translator client bootstrap")
    label.setMinimumSize(360, 120)
    label.show()
    return int(app.exec())


if __name__ == "__main__":
    raise SystemExit(run())
